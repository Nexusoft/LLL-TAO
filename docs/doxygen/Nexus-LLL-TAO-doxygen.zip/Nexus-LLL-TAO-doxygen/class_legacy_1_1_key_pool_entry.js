var class_legacy_1_1_key_pool_entry =
[
    [ "KeyPoolEntry", "class_legacy_1_1_key_pool_entry.html#a44be1f03ddc53c8198b0fc2b3510ac1e", null ],
    [ "KeyPoolEntry", "class_legacy_1_1_key_pool_entry.html#ae60187c1f7c71b9de57b0ae82ab35c9d", null ],
    [ "nTime", "class_legacy_1_1_key_pool_entry.html#abc4b9021f0f29ff8a0acdb69070ba1a5", null ],
    [ "vchPubKey", "class_legacy_1_1_key_pool_entry.html#a768f50ca0af7ae98f242155e9910fc12", null ]
];