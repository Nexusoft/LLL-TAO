var class_legacy_1_1_c_merkle_tx =
[
    [ "CMerkleTx", "class_legacy_1_1_c_merkle_tx.html#aa60e70231d710d0b30572cb504f5887b", null ],
    [ "CMerkleTx", "class_legacy_1_1_c_merkle_tx.html#a178af0088f7226921e660f844dd18b0b", null ],
    [ "GetBlocksToMaturity", "class_legacy_1_1_c_merkle_tx.html#a3636c1a6ed0870a5c0aad306bfd12ba5", null ],
    [ "IMPLEMENT_SERIALIZE", "class_legacy_1_1_c_merkle_tx.html#ab5d55a25954015ca8358bf15b6be1392", null ],
    [ "IsInMainChain", "class_legacy_1_1_c_merkle_tx.html#a1c3c19169f1184fbca45cab4ba4b493f", null ],
    [ "hashBlock", "class_legacy_1_1_c_merkle_tx.html#a2422e2987de2d2f18bc4e3bb5af32d3b", null ],
    [ "nIndex", "class_legacy_1_1_c_merkle_tx.html#a261c465916d93320ed7bba8376056501", null ],
    [ "vMerkleBranch", "class_legacy_1_1_c_merkle_tx.html#ad1e18a156c86d02c28018ce915368f7c", null ]
];