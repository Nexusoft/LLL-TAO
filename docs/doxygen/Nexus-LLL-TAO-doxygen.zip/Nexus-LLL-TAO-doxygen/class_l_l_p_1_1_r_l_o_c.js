var class_l_l_p_1_1_r_l_o_c =
[
    [ "strInterface", "class_l_l_p_1_1_r_l_o_c.html#a3a746ecc7463c0f35deab20c9752a4f7", null ],
    [ "strRLOCName", "class_l_l_p_1_1_r_l_o_c.html#a3cea2e951a2fc614b7b9e5e7f7e3d997", null ],
    [ "strTranslatedRLOC", "class_l_l_p_1_1_r_l_o_c.html#a61444261fee2bf45640ee07f79265eae", null ]
];