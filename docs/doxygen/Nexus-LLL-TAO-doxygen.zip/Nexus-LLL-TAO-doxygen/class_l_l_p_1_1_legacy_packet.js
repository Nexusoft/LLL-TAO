var class_l_l_p_1_1_legacy_packet =
[
    [ "LegacyPacket", "class_l_l_p_1_1_legacy_packet.html#a3244daee14d1af6439f1f63ebc86941f", null ],
    [ "LegacyPacket", "class_l_l_p_1_1_legacy_packet.html#aa112f497ed61e138e6b706b883c379c3", null ],
    [ "Complete", "class_l_l_p_1_1_legacy_packet.html#a710ed8dea6fbe6ce655e151510071b1b", null ],
    [ "GetBytes", "class_l_l_p_1_1_legacy_packet.html#a4c6ba6ab25332d4a0e7d633e3d291999", null ],
    [ "GetMessage", "class_l_l_p_1_1_legacy_packet.html#a2083ec8c02bfc7cd6e5270d4601d540d", null ],
    [ "Header", "class_l_l_p_1_1_legacy_packet.html#abac05440013a4e4ae1f9f96ab2f87e99", null ],
    [ "IMPLEMENT_SERIALIZE", "class_l_l_p_1_1_legacy_packet.html#aecc1c685ba8c1cec173eb17344919b4c", null ],
    [ "IsNull", "class_l_l_p_1_1_legacy_packet.html#a0d12ec42d3baabd1dd74bde3d957921a", null ],
    [ "IsValid", "class_l_l_p_1_1_legacy_packet.html#a23fa2ed850d41462cb237ce397ca5abc", null ],
    [ "SetChecksum", "class_l_l_p_1_1_legacy_packet.html#ad114d70df99409160dfe1bfd388bab9d", null ],
    [ "SetData", "class_l_l_p_1_1_legacy_packet.html#a710ed4a4e0a8abf081f66f9d2ecb4d14", null ],
    [ "SetHeader", "class_l_l_p_1_1_legacy_packet.html#aa111e756d5b48158f28ea82de32907db", null ],
    [ "SetLength", "class_l_l_p_1_1_legacy_packet.html#a6864a187cfce412751d0ba6c97d49c00", null ],
    [ "SetMessage", "class_l_l_p_1_1_legacy_packet.html#a21ef356d7a217e21364c43d45a14e730", null ],
    [ "CHECKSUM", "class_l_l_p_1_1_legacy_packet.html#a9f97b6d63a02bd8455d42167cc60a882", null ],
    [ "DATA", "class_l_l_p_1_1_legacy_packet.html#a47988cb58ed3ae87f2cbc05ba03e3483", null ],
    [ "HEADER", "class_l_l_p_1_1_legacy_packet.html#a232745965084f6d528fd5ca604ff19da", null ],
    [ "LENGTH", "class_l_l_p_1_1_legacy_packet.html#a1e90b1a14eb85316365fd75fe80bf085", null ],
    [ "MESSAGE", "class_l_l_p_1_1_legacy_packet.html#ad4c706bb6b5c315c5dcd1d3e26c89313", null ]
];