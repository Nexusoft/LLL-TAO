var _l_l_d_2templates_2transaction_8h =
[
    [ "SectorTransaction", "class_l_l_d_1_1_sector_transaction.html", "class_l_l_d_1_1_sector_transaction" ],
    [ "NEXUS_LLD_TEMPLATES_TRANSACTION_H", "_l_l_d_2templates_2transaction_8h.html#ad03e0bab18c91dd6623872ed00eb9471", null ]
];