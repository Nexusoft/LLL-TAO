var _l_l_p_2types_2legacy_8h =
[
    [ "LegacyNode", "class_l_l_p_1_1_legacy_node.html", "class_l_l_p_1_1_legacy_node" ],
    [ "addrMyNode", "_l_l_p_2types_2legacy_8h.html#aed9b7d41fff9a37b1e5afe46dcdd9b6e", null ]
];