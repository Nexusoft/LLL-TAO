var class_base_stream =
[
    [ "BaseStream", "class_base_stream.html#a2c6119066c265053ea00a498d4ecaef0", null ],
    [ "BaseStream", "class_base_stream.html#aadf10b9846f39bc7994482ba774a1074", null ],
    [ "begin", "class_base_stream.html#ae104ff2777a3ccd614a290dd286a4966", null ],
    [ "end", "class_base_stream.html#a335ff229c96279d996df8755c1cd95d3", null ],
    [ "get", "class_base_stream.html#ae3dc771769757abed231d3e791725f31", null ],
    [ "IsNull", "class_base_stream.html#a894b11daa2b200ba94899477222c5703", null ],
    [ "read", "class_base_stream.html#ad2d9c0fe23c554e2063798290903365b", null ],
    [ "reset", "class_base_stream.html#ae0c4a0d5de69f8adc33641495aac673d", null ],
    [ "seek", "class_base_stream.html#ad43c32d81d595073d62a867ec8e08c1d", null ],
    [ "SetNull", "class_base_stream.html#ad9188a83c947bfaeaea018d1ece2c721", null ],
    [ "size", "class_base_stream.html#a39e795c2dc6d446ca520ad898f88183b", null ],
    [ "write", "class_base_stream.html#a0cb2891acebf4247e791fd6e02d81441", null ],
    [ "nReadPos", "class_base_stream.html#ab6dc04ff284377aeca5f328bb5854a7a", null ],
    [ "vchData", "class_base_stream.html#a3f29fc2cc44a407cb802d6a739e7b4f6", null ]
];