var class_l_l_d_1_1_address_d_b =
[
    [ "AddressDB", "class_l_l_d_1_1_address_d_b.html#a5e4eb701cb8dffbcc5464a9ca8a02b01", null ],
    [ "ReadTrustAddress", "class_l_l_d_1_1_address_d_b.html#a8f28776c54d1364d17778d29ab25d106", null ],
    [ "WriteTrustAddress", "class_l_l_d_1_1_address_d_b.html#a397a2d44f3f61ba7028e75c9a3e43922", null ]
];