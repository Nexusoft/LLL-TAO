var class_l_l_d_1_1_local_d_b =
[
    [ "LocalDB", "class_l_l_d_1_1_local_d_b.html#a9170b82ff85692410d6d8e7d5940959c", null ],
    [ "HasGenesis", "class_l_l_d_1_1_local_d_b.html#a9cc8c151ecb1e8689e74437aec9389de", null ],
    [ "ReadGenesis", "class_l_l_d_1_1_local_d_b.html#acd640c9f55b979b5d9b4809b4e1f1704", null ],
    [ "ReadLast", "class_l_l_d_1_1_local_d_b.html#a04e9492fc525513303956cb83e8c7931", null ],
    [ "WriteGenesis", "class_l_l_d_1_1_local_d_b.html#ad672e7b44d855c794baf0886a8be6fa8", null ],
    [ "WriteLast", "class_l_l_d_1_1_local_d_b.html#a61f2898aa5349ddd580076c619722132", null ]
];