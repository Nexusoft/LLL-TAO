var _l_l_d_2include_2version_8h =
[
    [ "DATABASE_BUILD", "_l_l_d_2include_2version_8h.html#a5819bd7cdde295f1e770ad1e1d5619a8", null ],
    [ "DATABASE_MAJOR", "_l_l_d_2include_2version_8h.html#a5c224bbd17703adcf0087db751a3012d", null ],
    [ "DATABASE_MINOR", "_l_l_d_2include_2version_8h.html#a46fb8f912153b96f3b5d1493379aa53c", null ],
    [ "DATABASE_PATCH", "_l_l_d_2include_2version_8h.html#a9404efa23262ad2a6d95f91741cd87d6", null ],
    [ "NEXUS_LLD_INCLUDE_VERSION_H", "_l_l_d_2include_2version_8h.html#ac45ecc45bc4c13808dfdc6150861c12b", null ],
    [ "DATABASE_NAME", "_l_l_d_2include_2version_8h.html#a002728dde85a72d43fc08a6a8136c02e", null ],
    [ "DATABASE_VERSION", "_l_l_d_2include_2version_8h.html#a41913fa3195b001dd49dfbb085885b83", null ]
];