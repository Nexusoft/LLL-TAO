var _ledger_2include_2supply_8h =
[
    [ "NEXUS_TAO_LEDGER_INCLUDE_SUPPLY_H", "_ledger_2include_2supply_8h.html#a1bb0ea77d63f6ca99e9efb1b68d875ef", null ],
    [ "CompoundSubsidy", "_ledger_2include_2supply_8h.html#ad5d8a997fd2b3e76b6de1e1a70dc2edb", null ],
    [ "GetChainAge", "_ledger_2include_2supply_8h.html#a3830afafba2a3b86a6ed5d2f02222602", null ],
    [ "GetCoinbaseReward", "_ledger_2include_2supply_8h.html#a4eee727ef885176440469ddb2690562b", null ],
    [ "GetFractionalSubsidy", "_ledger_2include_2supply_8h.html#a774b495ce290e6c093a8c8e8fe7c7f27", null ],
    [ "GetMoneySupply", "_ledger_2include_2supply_8h.html#a7937175022502d37f127cc50349f67b0", null ],
    [ "GetReleasedReserve", "_ledger_2include_2supply_8h.html#a901c0200ef70db003a8782f5ddbf35bd", null ],
    [ "GetSubsidy", "_ledger_2include_2supply_8h.html#a01542cb2e353ad73e66d656f8906019b", null ],
    [ "ReleaseRewards", "_ledger_2include_2supply_8h.html#a61d759d36329a62cb54df9ed5561ebc8", null ],
    [ "SubsidyInterval", "_ledger_2include_2supply_8h.html#abfb517617253519e984e93ee03467182", null ],
    [ "decay", "_ledger_2include_2supply_8h.html#afe64db38180e5a58cdb1f53883a693da", null ]
];