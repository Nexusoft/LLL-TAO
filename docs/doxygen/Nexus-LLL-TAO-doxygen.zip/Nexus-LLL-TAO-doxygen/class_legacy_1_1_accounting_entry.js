var class_legacy_1_1_accounting_entry =
[
    [ "AccountingEntry", "class_legacy_1_1_accounting_entry.html#ac27a42f672b3681d8c3ba28adf9ba390", null ],
    [ "SetNull", "class_legacy_1_1_accounting_entry.html#ad436deb83e368a7b67181fae62e6afa8", null ],
    [ "nCreditDebit", "class_legacy_1_1_accounting_entry.html#a0475576c5c89eb6b185fd191d42daaa6", null ],
    [ "nTime", "class_legacy_1_1_accounting_entry.html#ae576b24ada186e215027e777c3803b2c", null ],
    [ "strAccount", "class_legacy_1_1_accounting_entry.html#ad14419b55f19507df42ba7a7fce75796", null ],
    [ "strComment", "class_legacy_1_1_accounting_entry.html#a9e14d97390d8d2a810488e02583f13c0", null ],
    [ "strOtherAccount", "class_legacy_1_1_accounting_entry.html#a8e39c3ea68a33c5f9b76495ad6fc8489", null ]
];