var class_legacy_1_1_master_key =
[
    [ "IMPLEMENT_SERIALIZE", "class_legacy_1_1_master_key.html#a58b2f8166025549477a5a46b63949526", null ],
    [ "nDerivationMethod", "class_legacy_1_1_master_key.html#a3ad7ef7a7a2f1dbb1321253b7539e6e9", null ],
    [ "nDeriveIterations", "class_legacy_1_1_master_key.html#a6daa5f45346088f3715fb525fca5d479", null ],
    [ "vchCryptedKey", "class_legacy_1_1_master_key.html#a723ba4b34be8b8ef9a415f0ec2a6b5d3", null ],
    [ "vchOtherDerivationParameters", "class_legacy_1_1_master_key.html#aa62ab3dc05ea6b6f5b0e5f412c6858bf", null ],
    [ "vchSalt", "class_legacy_1_1_master_key.html#afed3efb43853a2fdf1c4436a8497cf84", null ]
];