var class_legacy_1_1_output =
[
    [ "Output", "class_legacy_1_1_output.html#a139fe43ca4fde5ecd92b027448f15fa7", null ],
    [ "print", "class_legacy_1_1_output.html#abc1dbfc7c0ea42b7db7aabb843857fdb", null ],
    [ "ToString", "class_legacy_1_1_output.html#a5a3d3632223e2e2b6a4dce606638a10e", null ],
    [ "i", "class_legacy_1_1_output.html#af8dad22759fd24dd27fb403af666ea93", null ],
    [ "nDepth", "class_legacy_1_1_output.html#a8c672262543f8d4ba5b1a7759d4ff1d0", null ],
    [ "walletTx", "class_legacy_1_1_output.html#acc9e739e44760ee14bcb9d307ee4b7af", null ]
];