var class_c_average =
[
    [ "CAverage", "class_c_average.html#a3a74935994f2c9c46203de2bf8bc6ed6", null ],
    [ "Add", "class_c_average.html#add2b245f05f0c0a03c8424c321b0b901", null ],
    [ "Average", "class_c_average.html#a472c0abc08fcaeaee465fc28025f0b93", null ]
];