var class_legacy_1_1_reserve_key =
[
    [ "ReserveKey", "class_legacy_1_1_reserve_key.html#ad7e247ae506db1102e1bbccedc174650", null ],
    [ "ReserveKey", "class_legacy_1_1_reserve_key.html#ad502c18c58f88a422f3fbe57f6731830", null ],
    [ "~ReserveKey", "class_legacy_1_1_reserve_key.html#acac06b69586d9f6d8a7a91310c53688b", null ],
    [ "ReserveKey", "class_legacy_1_1_reserve_key.html#aca98089e99bfab0fc7f0a73f10a30c9b", null ],
    [ "GetReservedKey", "class_legacy_1_1_reserve_key.html#acef8a3af4255e27a242f64fe5c56b902", null ],
    [ "KeepKey", "class_legacy_1_1_reserve_key.html#ab700affc7d40d92bfae029f83b3da66e", null ],
    [ "operator=", "class_legacy_1_1_reserve_key.html#a7eef1b85dff3789f3a66a751ebe8a0f9", null ],
    [ "ReturnKey", "class_legacy_1_1_reserve_key.html#a9904b15bc3faa6e50ea650ade96b85c8", null ],
    [ "nPoolIndex", "class_legacy_1_1_reserve_key.html#a1b9ddea521fd50aff90b3df72ec10cde", null ],
    [ "vchPubKey", "class_legacy_1_1_reserve_key.html#a60246118370ae21cbd5846d636ba7237", null ],
    [ "wallet", "class_legacy_1_1_reserve_key.html#a6e6621fa5819f1d442336269b726620c", null ]
];