var _t_a_o_2_ledger_2include_2time_8h =
[
    [ "int64_t", "_t_a_o_2_ledger_2include_2time_8h.html#a996e72f71b11a5bb8b3b7b6936b1516d", null ],
    [ "GetUnifiedAverage", "_t_a_o_2_ledger_2include_2time_8h.html#a923cd2120fb30c108034cc77602239cb", null ],
    [ "InitializeUnifiedTime", "_t_a_o_2_ledger_2include_2time_8h.html#a3af86c0c03a58edf72393b2fe6e676c4", null ],
    [ "ThreadUnifiedSamples", "_t_a_o_2_ledger_2include_2time_8h.html#a3032652bd064048bfa770139e0d9fd5d", null ],
    [ "fIsSeedNode", "_t_a_o_2_ledger_2include_2time_8h.html#a57710b13b7f8d8e5e464ba9b7eab7145", null ],
    [ "fIsTimeSeed", "_t_a_o_2_ledger_2include_2time_8h.html#a7dd48bf6bec1818baa3b841cb2fc314d", null ],
    [ "fTimeUnified", "_t_a_o_2_ledger_2include_2time_8h.html#ae0772f214f15358b90de44fa69857dee", null ],
    [ "MAX_UNIFIED_DRIFT", "_t_a_o_2_ledger_2include_2time_8h.html#a833e7837ded3ff2c8ef3223062c99730", null ],
    [ "SEED_NODES", "_t_a_o_2_ledger_2include_2time_8h.html#a2440c2c7e800c91548a944f0b9f755f6", null ],
    [ "UNIFIED_AVERAGE_OFFSET", "_t_a_o_2_ledger_2include_2time_8h.html#a9adc116ee8c2c92d95ef8de5704af774", null ],
    [ "UNIFIED_LOCAL_OFFSET", "_t_a_o_2_ledger_2include_2time_8h.html#a2550e3aec7f88e08eb95898ec4ef837f", null ],
    [ "UNIFIED_TIME_DATA", "_t_a_o_2_ledger_2include_2time_8h.html#a4d5d4438dcf4bca24e7e24b120a864b5", null ]
];