var base__miner_8h =
[
    [ "BaseMiner", "class_l_l_p_1_1_base_miner.html", "class_l_l_p_1_1_base_miner" ],
    [ "NEXUS_LLP_TYPES_BASE_MINER_H", "base__miner_8h.html#af23aae8c47f18d0d8bf0a63998dff712", null ]
];