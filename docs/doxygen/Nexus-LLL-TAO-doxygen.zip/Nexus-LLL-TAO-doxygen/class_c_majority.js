var class_c_majority =
[
    [ "CMajority", "class_c_majority.html#afad3bf86d2e4ea2ce2602cf6e3f91b71", null ],
    [ "Add", "class_c_majority.html#a8cfd0134c08561dd570a1c10d7738268", null ],
    [ "clear", "class_c_majority.html#a54a5ff334e1599ae8a672f6900bb9936", null ],
    [ "Majority", "class_c_majority.html#aa1ba13c0a899a562fb1e0a915c45f5bf", null ],
    [ "Samples", "class_c_majority.html#a1271e4228ccfbd9988adadabc59ba063", null ]
];