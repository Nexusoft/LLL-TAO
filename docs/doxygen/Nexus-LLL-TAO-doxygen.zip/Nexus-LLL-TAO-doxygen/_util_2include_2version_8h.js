var _util_2include_2version_8h =
[
    [ "CLIENT_BUILD", "_util_2include_2version_8h.html#adcab02a649f6c75861f623b93062ac98", null ],
    [ "CLIENT_DATE", "_util_2include_2version_8h.html#afbc8ba04cd89429d20b3d403fc1b2023", null ],
    [ "CLIENT_MAJOR", "_util_2include_2version_8h.html#a268ec62427b707a9ff615a18d462687c", null ],
    [ "CLIENT_MINOR", "_util_2include_2version_8h.html#a0cef37e7e651ff301c6bf70d843a4e98", null ],
    [ "CLIENT_PATCH", "_util_2include_2version_8h.html#a00bea193ffe56fa929d03b93c374317f", null ],
    [ "CLIENT_VERSION", "_util_2include_2version_8h.html#a2451570d8ae6ea5fbe833d624e7c58eb", null ],
    [ "CLIENT_VERSION_BUILD_STRING", "_util_2include_2version_8h.html#a98754f9516f4473e2734531a6650070a", null ]
];