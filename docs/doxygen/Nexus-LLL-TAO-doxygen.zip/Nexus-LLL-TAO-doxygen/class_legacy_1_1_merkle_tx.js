var class_legacy_1_1_merkle_tx =
[
    [ "MerkleTx", "class_legacy_1_1_merkle_tx.html#afebda87b5ef5c0c348655c784295d78f", null ],
    [ "MerkleTx", "class_legacy_1_1_merkle_tx.html#aada153af6720a3b4c073803e8c31c04c", null ],
    [ "GetBlocksToMaturity", "class_legacy_1_1_merkle_tx.html#a939fe61b84effe63aa103c8e291d1fee", null ],
    [ "IMPLEMENT_SERIALIZE", "class_legacy_1_1_merkle_tx.html#acf5a1d4dd5f779f6c6323beaf6a06f9f", null ],
    [ "IsInMainChain", "class_legacy_1_1_merkle_tx.html#a5cbaa7604611381126cdf07c5ff3b706", null ],
    [ "hashBlock", "class_legacy_1_1_merkle_tx.html#a5130b266fe61459cfe88a55dac99247d", null ],
    [ "nIndex", "class_legacy_1_1_merkle_tx.html#a05a09852aa1a6042ab560de1bc980e87", null ],
    [ "vMerkleBranch", "class_legacy_1_1_merkle_tx.html#ac0f47fc255a49d257bbc3d1830df3505", null ]
];