var _t_a_o_2_operation_2include_2create_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_CREATE_H", "_t_a_o_2_operation_2include_2create_8h.html#adcb2835e8e53128d6a7ff3530cd39575", null ],
    [ "Commit", "_t_a_o_2_operation_2include_2create_8h.html#acde21d9f2e5b2aec91ef644941e52e06", null ],
    [ "Execute", "_t_a_o_2_operation_2include_2create_8h.html#a3622bdca8d16a8fb45eb0e6afa3a50dc", null ],
    [ "Verify", "_t_a_o_2_operation_2include_2create_8h.html#ad74171b44206da6cd1efa35412aec394", null ]
];