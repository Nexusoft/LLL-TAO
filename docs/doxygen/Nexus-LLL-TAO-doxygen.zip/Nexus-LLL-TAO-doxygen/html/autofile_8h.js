var autofile_8h =
[
    [ "AutoFile", "class_auto_file.html", "class_auto_file" ],
    [ "NEXUS_UTIL_TEMPLATES_AUTOFILE_H", "autofile_8h.html#ab3f1ad2af5e3711f445eac86a2d01be4", null ]
];