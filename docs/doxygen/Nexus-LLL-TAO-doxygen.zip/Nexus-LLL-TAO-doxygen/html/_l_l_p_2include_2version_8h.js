var _l_l_p_2include_2version_8h =
[
    [ "NEXUS_LLP_INCLUDE_VERSION_H", "_l_l_p_2include_2version_8h.html#aea3654bb355e855ec2d6838c571676fe", null ],
    [ "PROTOCOL_BUILD", "_l_l_p_2include_2version_8h.html#aced602e9836a66715781404fef53a063", null ],
    [ "PROTOCOL_MAJOR", "_l_l_p_2include_2version_8h.html#a7ff33ddb3883ffabdc73b1f00832bada", null ],
    [ "PROTOCOL_MINOR", "_l_l_p_2include_2version_8h.html#addb24190d0de1366a5db28c4395c1bb1", null ],
    [ "PROTOCOL_REVISION", "_l_l_p_2include_2version_8h.html#a04f02cd21d294e984f016eb3e2ec1388", null ],
    [ "MIN_PROTO_VERSION", "_l_l_p_2include_2version_8h.html#ae88a39fbc74d5f27e402d0d9f61a77db", null ],
    [ "MIN_TRITIUM_VERSION", "_l_l_p_2include_2version_8h.html#a1b5ca5af2cadaf0cc47ce3f4ad682be2", null ],
    [ "PROTOCOL_VERSION", "_l_l_p_2include_2version_8h.html#a0e94f9254798e5e6cd0fb61454e428a9", null ],
    [ "strProtocolName", "_l_l_p_2include_2version_8h.html#aa22e0d47e136157452b4ef4364bb004e", null ]
];