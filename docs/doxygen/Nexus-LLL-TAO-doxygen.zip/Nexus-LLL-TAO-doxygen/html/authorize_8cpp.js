var authorize_8cpp =
[
    [ "Authorize", "authorize_8cpp.html#a1809bc6cd53ebe361d41959bf694b39c", null ]
];