var _t_a_o_2_operation_2types_2contract_8h =
[
    [ "Contract", "class_t_a_o_1_1_operation_1_1_contract.html", "class_t_a_o_1_1_operation_1_1_contract" ],
    [ "NEXUS_TAO_OPERATION_TYPES_CONTRACT_H", "_t_a_o_2_operation_2types_2contract_8h.html#abfd193cb207190b81f8a1ab146b46ebc", null ]
];