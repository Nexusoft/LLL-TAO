var _t_a_o_2_operation_2include_2trust_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_TRUST_H", "_t_a_o_2_operation_2include_2trust_8h.html#a986414a69167c023052ca169c80bc492", null ],
    [ "Commit", "_t_a_o_2_operation_2include_2trust_8h.html#ac30dc9b6c8e829e8ff3d003eee606a76", null ],
    [ "Execute", "_t_a_o_2_operation_2include_2trust_8h.html#ad62a07c777471d86ea0a0f2afd8d62aa", null ],
    [ "Verify", "_t_a_o_2_operation_2include_2trust_8h.html#ad4f971e484bdcd9c46dc9ef2c33225d8", null ]
];