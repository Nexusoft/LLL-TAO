var _operation_2include_2genesis_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_GENESIS_H", "_operation_2include_2genesis_8h.html#ac9fedea24cf798bf956c99ba4995c6c5", null ],
    [ "Commit", "_operation_2include_2genesis_8h.html#ac96b3c2298a922cabc294056ce3da8e6", null ],
    [ "Execute", "_operation_2include_2genesis_8h.html#a2fba3f253cc29c682ea542c28b9b5c12", null ],
    [ "Verify", "_operation_2include_2genesis_8h.html#ae278a1c370d55df2e433810b21da41c3", null ]
];