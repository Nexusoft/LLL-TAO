var ambassador_8h =
[
    [ "NEXUS_LEGACY_INCLUDE_AMBASSADOR_H", "ambassador_8h.html#a67ec254a7919bb19480129e6d32b7703", null ],
    [ "InitializeScripts", "ambassador_8h.html#ac7687c927ad06ecd3086696582418899", null ],
    [ "AMBASSADOR_ADDRESSES", "ambassador_8h.html#aa5082788344f54e2ca592140e0d699b9", null ],
    [ "AMBASSADOR_ADDRESSES_RECYCLED", "ambassador_8h.html#ab5045e454521df0383445f1ee36b7ef8", null ],
    [ "DEVELOPER_ADDRESSES", "ambassador_8h.html#a85d05f04a36bd62e49e45b6cb6de3497", null ],
    [ "DEVELOPER_ADDRESSES_RECYCLED", "ambassador_8h.html#a932cc77fa9521718ffabe75014acf297", null ],
    [ "TESTNET_DUMMY_ADDRESS", "ambassador_8h.html#a031e8d00a55d52b971cd689199e71e17", null ],
    [ "TESTNET_DUMMY_AMBASSADOR_RECYCLED", "ambassador_8h.html#a76f88ee8809cebabf4596931ffc8f72d", null ],
    [ "TESTNET_DUMMY_DEVELOPER_RECYCLED", "ambassador_8h.html#a729e559708ff21d6c0ac26a96cdba9c3", null ]
];