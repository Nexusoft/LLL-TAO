var _legacy_2create_8cpp =
[
    [ "AddTransactions", "_legacy_2create_8cpp.html#ae395a948d048f527567a1a53f89765c5", null ],
    [ "CheckWork", "_legacy_2create_8cpp.html#ad3966eee9aac039fe3b9b033e1a336b3", null ],
    [ "CreateBlock", "_legacy_2create_8cpp.html#ae8afa6c207dbc3ed6301eb7b25f39bd8", null ],
    [ "CreateCoinbase", "_legacy_2create_8cpp.html#a091ddd4d632859f54fc5e1a5bbe07b05", null ],
    [ "CreateCoinstake", "_legacy_2create_8cpp.html#a54a2ac69cdf4abdc99af17bb1501741e", null ],
    [ "SignBlock", "_legacy_2create_8cpp.html#aac4b1b8466dab4f93a630616f0d1a832", null ]
];