var _ledger_2state_8cpp =
[
    [ "GetLastState", "_ledger_2state_8cpp.html#a2f8034c7d09c325576aac8094570e6ef", null ]
];