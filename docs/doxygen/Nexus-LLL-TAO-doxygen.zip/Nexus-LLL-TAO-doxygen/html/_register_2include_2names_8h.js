var _register_2include_2names_8h =
[
    [ "NEXUS_TAO_REGISTER_INCLUDE_UTILS_H", "_register_2include_2names_8h.html#adceed2e9c4981ceb029e2eb2c870e06b", null ],
    [ "GetNameRegister", "_register_2include_2names_8h.html#adf4ca4b90a92b33d09ebefebb23de50d", null ],
    [ "GetNamespaceRegister", "_register_2include_2names_8h.html#a9fd498eb769fecba808f5e2ed83882b9", null ]
];