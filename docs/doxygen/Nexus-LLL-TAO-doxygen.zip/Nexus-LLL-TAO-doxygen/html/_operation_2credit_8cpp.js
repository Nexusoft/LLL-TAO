var _operation_2credit_8cpp =
[
    [ "Credit", "_operation_2credit_8cpp.html#a389e788558bb16bfc3e90062126b6b80", null ]
];