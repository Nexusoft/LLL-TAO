var block_8h =
[
    [ "Block", "class_t_a_o_1_1_ledger_1_1_block.html", "class_t_a_o_1_1_ledger_1_1_block" ],
    [ "NEXUS_TAO_LEDGER_TYPES_BLOCK_H", "block_8h.html#af72ef6d97e138acb7ec11d0868c0b657", null ]
];