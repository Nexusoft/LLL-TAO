var _t_a_o_2_a_p_i_2include_2ledger_8h =
[
    [ "Ledger", "class_t_a_o_1_1_a_p_i_1_1_ledger.html", "class_t_a_o_1_1_a_p_i_1_1_ledger" ],
    [ "NEXUS_TAO_API_INCLUDE_LEDGER_H", "_t_a_o_2_a_p_i_2include_2ledger_8h.html#ab7078c29eaefb1eb33bf3decde7ae2f9", null ]
];