var _legacy_2types_2locator_8h =
[
    [ "Locator", "class_legacy_1_1_locator.html", "class_legacy_1_1_locator" ],
    [ "NEXUS_LEGACY_TYPES_LOCATOR_H", "_legacy_2types_2locator_8h.html#a918417567b7705fcea6e98d074c8eb69", null ]
];