var checkpoints_8cpp =
[
    [ "HardenCheckpoint", "checkpoints_8cpp.html#ac58e18aff3a6db53f000b82a380fe185", null ],
    [ "IsDescendant", "checkpoints_8cpp.html#a37be131e8c5b1290433535b81d93d657", null ],
    [ "IsNewTimespan", "checkpoints_8cpp.html#a4c2ec7c656bc0605b6c69e8de6dcd27c", null ],
    [ "CHECKPOINT_TIMESPAN", "checkpoints_8cpp.html#a1c1006e63bcdf9344d8e932742df2975", null ]
];