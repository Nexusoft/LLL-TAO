var _util_2include_2version_8h =
[
    [ "NEXUS_UTIL_INCLUDE_VERSION_H", "_util_2include_2version_8h.html#a28c66995ef6ddf7cd78dc0b4660dbeb1", null ],
    [ "CLIENT_DATE", "_util_2include_2version_8h.html#afbc8ba04cd89429d20b3d403fc1b2023", null ],
    [ "CLIENT_MAJOR", "_util_2include_2version_8h.html#a491fa2c4dc88558a6a370d294ed09ae5", null ],
    [ "CLIENT_MINOR", "_util_2include_2version_8h.html#a8b91d3698603dfca9f588a331fa5cb6a", null ],
    [ "CLIENT_PATCH", "_util_2include_2version_8h.html#a0789247010a1a221f559c6c9a47db0a8", null ],
    [ "CLIENT_VERSION", "_util_2include_2version_8h.html#a2f53a921cd686652b96fac6f92395a4b", null ],
    [ "CLIENT_VERSION_BUILD_STRING", "_util_2include_2version_8h.html#a98754f9516f4473e2734531a6650070a", null ]
];