var _keccak_duplex_8h =
[
    [ "Keccak_DuplexInstanceStruct", "struct_keccak___duplex_instance_struct.html", "struct_keccak___duplex_instance_struct" ],
    [ "ALIGN", "_keccak_duplex_8h.html#ae4ff5a07c6ff43ed11a3887ef7d524f2", null ],
    [ "Keccak_DuplexInstance", "_keccak_duplex_8h.html#ad726e2297f9af200c7a2de62e9b341ca", null ],
    [ "Keccak_Duplexing", "_keccak_duplex_8h.html#a30b113e54231e67c706b957a926ef3bd", null ],
    [ "Keccak_DuplexInitialize", "_keccak_duplex_8h.html#a8ab05ccb1a01732491a1a4add8eb1c1d", null ]
];