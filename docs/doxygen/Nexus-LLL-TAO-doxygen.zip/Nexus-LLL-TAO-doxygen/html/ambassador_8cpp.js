var ambassador_8cpp =
[
    [ "InitializeScripts", "ambassador_8cpp.html#ac7687c927ad06ecd3086696582418899", null ],
    [ "AMBASSADOR_SCRIPT_SIGNATURES", "ambassador_8cpp.html#a466422d62ea19c596e8ec7cff6d88edd", null ],
    [ "AMBASSADOR_SCRIPT_SIGNATURES_RECYCLED", "ambassador_8cpp.html#aa54bd8541f0fb955817c870927220bfb", null ],
    [ "DEVELOPER_SCRIPT_SIGNATURES", "ambassador_8cpp.html#ac9162a27bcdda9fd79d8f9cbe0af358a", null ],
    [ "DEVELOPER_SCRIPT_SIGNATURES_RECYCLED", "ambassador_8cpp.html#a1672bf0b4894e0845ca25523c7315b00", null ],
    [ "TESTNET_DUMMY_SIGNATURE", "ambassador_8cpp.html#aecff55e7153ddc914fb82ed1c7d499c1", null ],
    [ "TESTNET_DUMMY_SIGNATURE_AMBASSADOR_RECYCLED", "ambassador_8cpp.html#a0dd3f69b416ccdf3b525d396500cc434", null ],
    [ "TESTNET_DUMMY_SIGNATURE_DEVELOPER_RECYCLED", "ambassador_8cpp.html#aca5235893522ee71b88bbea90e6bd22f", null ]
];