var _legacy_2types_2transaction_8h =
[
    [ "Transaction", "class_legacy_1_1_transaction.html", "class_legacy_1_1_transaction" ],
    [ "NEXUS_LEGACY_TYPES_TRANSACTION_H", "_legacy_2types_2transaction_8h.html#a7eef4fb23db2ade685fe9c61a30a483e", null ]
];