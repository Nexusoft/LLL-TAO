var class_base_stream =
[
    [ "BaseStream", "class_base_stream.html#a2c6119066c265053ea00a498d4ecaef0", null ],
    [ "BaseStream", "class_base_stream.html#aadf10b9846f39bc7994482ba774a1074", null ],
    [ "~BaseStream", "class_base_stream.html#a0fd6020feee8de82d3eafe4310fddb2a", null ],
    [ "begin", "class_base_stream.html#ae104ff2777a3ccd614a290dd286a4966", null ],
    [ "Bytes", "class_base_stream.html#a937cf7b88d1c1e275a62d493b4ea6c2c", null ],
    [ "end", "class_base_stream.html#a335ff229c96279d996df8755c1cd95d3", null ],
    [ "get", "class_base_stream.html#ac65309cebda08bd69287faa280a1566a", null ],
    [ "IsNull", "class_base_stream.html#a894b11daa2b200ba94899477222c5703", null ],
    [ "pos", "class_base_stream.html#a0b5048617221d6bb27e85e74f12fa1be", null ],
    [ "read", "class_base_stream.html#ad160f7d00d14104c19a858f62a0cae75", null ],
    [ "reset", "class_base_stream.html#ae0c4a0d5de69f8adc33641495aac673d", null ],
    [ "seek", "class_base_stream.html#a863c938309fb181ae993d6aa6fbe107a", null ],
    [ "SetNull", "class_base_stream.html#ad9188a83c947bfaeaea018d1ece2c721", null ],
    [ "size", "class_base_stream.html#ab6de917292559a7ef1f10eeb617b60fc", null ],
    [ "write", "class_base_stream.html#a1c738869a1ca01d91072c1005767aa36", null ],
    [ "nReadPos", "class_base_stream.html#ae0c9bbfaf4da9311b1ae02e03b6d4355", null ],
    [ "vchData", "class_base_stream.html#a3f29fc2cc44a407cb802d6a739e7b4f6", null ]
];