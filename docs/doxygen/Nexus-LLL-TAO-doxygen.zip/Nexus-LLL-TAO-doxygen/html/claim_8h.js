var claim_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_CLAIM_H", "claim_8h.html#aa57769f3ef5e3a6e6f8d6658048ed831", null ],
    [ "Commit", "claim_8h.html#a315c657aee92ab25f44b5923f73dc0c2", null ],
    [ "Execute", "claim_8h.html#a9f0ad0ac9c9f01e355d023ce180029f1", null ],
    [ "Verify", "claim_8h.html#a5091d4cfbfa98b3a44102abd98e9cc76", null ]
];