var blake2b_8c =
[
    [ "G", "blake2b_8c.html#a4fbc796e307d9128c5de14d17c3de42a", null ],
    [ "ROUND", "blake2b_8c.html#ab35e822e8226ebfbc2122810b5ac5827", null ],
    [ "TRY", "blake2b_8c.html#a9631a68bc0c927f3d068b07ee8d052ff", null ],
    [ "blake2b", "blake2b_8c.html#a5cf706554b84e6b4d763084ecefd6391", null ],
    [ "blake2b_final", "blake2b_8c.html#ae3265f4a4ba468da48c850ad815bed2d", null ],
    [ "blake2b_init", "blake2b_8c.html#a7cefd211bfec58d37d8b67741955ce8a", null ],
    [ "blake2b_init_key", "blake2b_8c.html#a039b52f87e2ba0ca16ebbc62bfd3f02a", null ],
    [ "blake2b_init_param", "blake2b_8c.html#ae453d8f2798df27cd1f4ea9b00b3a520", null ],
    [ "blake2b_long", "blake2b_8c.html#a9b077c7edb6f72a00f66c3db94ae6398", null ],
    [ "blake2b_update", "blake2b_8c.html#a1ee160fb796e342c9ee8a99ea0ffab0a", null ]
];