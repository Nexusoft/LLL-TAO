var blamka_round_ref_8h =
[
    [ "BLAKE2_ROUND_NOMSG", "blamka-round-ref_8h.html#abe378a9327fc6c654a136bb2f4e914d6", null ],
    [ "G", "blamka-round-ref_8h.html#a4770411521cb86ce3f7758c3d73d018b", null ]
];