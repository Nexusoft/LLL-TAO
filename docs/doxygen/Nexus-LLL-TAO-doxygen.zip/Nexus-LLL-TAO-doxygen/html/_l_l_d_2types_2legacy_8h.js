var _l_l_d_2types_2legacy_8h =
[
    [ "LegacyDB", "class_l_l_d_1_1_legacy_d_b.html", "class_l_l_d_1_1_legacy_d_b" ],
    [ "NEXUS_LLD_INCLUDE_LEGACY_H", "_l_l_d_2types_2legacy_8h.html#a0c601f7740c1b7c37e4275b7f2da46e3", null ]
];