var _ledger_2types_2state_8h =
[
    [ "BlockState", "class_t_a_o_1_1_ledger_1_1_block_state.html", "class_t_a_o_1_1_ledger_1_1_block_state" ],
    [ "NEXUS_TAO_LEDGER_TYPES_STATE_H", "_ledger_2types_2state_8h.html#ac7c1ec98a553b319923cab0d7e0b9b1f", null ],
    [ "GetLastState", "_ledger_2types_2state_8h.html#a2f8034c7d09c325576aac8094570e6ef", null ]
];