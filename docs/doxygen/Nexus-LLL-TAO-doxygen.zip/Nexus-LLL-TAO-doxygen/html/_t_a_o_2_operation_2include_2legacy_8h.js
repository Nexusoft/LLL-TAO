var _t_a_o_2_operation_2include_2legacy_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_LEGACY_H", "_t_a_o_2_operation_2include_2legacy_8h.html#a1859aa0e18169445eddc5bd34be739b0", null ],
    [ "Commit", "_t_a_o_2_operation_2include_2legacy_8h.html#a666ef5577feb0a568829c66dbc8a5fda", null ],
    [ "Execute", "_t_a_o_2_operation_2include_2legacy_8h.html#a60a7e63ee173310c7cd649f9715a6326", null ],
    [ "Verify", "_t_a_o_2_operation_2include_2legacy_8h.html#a3c0b90eb4e3c48ab3716b70b18b3b6e7", null ]
];