var _l_l_d_2include_2enum_8h =
[
    [ "NEXUS_LLD_INCLUDE_ENUM_H", "_l_l_d_2include_2enum_8h.html#a6bcc61986fc7dd510a7322a6df19d6d5", null ],
    [ "FLAGS", "_l_l_d_2include_2enum_8h.html#ae4f0f07118ad00fb42a503456480907e", [
      [ "APPEND", "_l_l_d_2include_2enum_8h.html#ae4f0f07118ad00fb42a503456480907ead691edb453b3e5d3cb1a9dde40897188", null ],
      [ "READONLY", "_l_l_d_2include_2enum_8h.html#ae4f0f07118ad00fb42a503456480907eab418929966342c4c6203df83a525a583", null ],
      [ "CREATE", "_l_l_d_2include_2enum_8h.html#ae4f0f07118ad00fb42a503456480907ea4ad3fded2e38d7d51a7f936bdae3f935", null ],
      [ "WRITE", "_l_l_d_2include_2enum_8h.html#ae4f0f07118ad00fb42a503456480907eaff661f1fa328fabe30d441615ac4d528", null ],
      [ "FORCE", "_l_l_d_2include_2enum_8h.html#ae4f0f07118ad00fb42a503456480907eaa35c2e6f8b3c3a824f0256e810581c3f", null ]
    ] ],
    [ "STATE", "_l_l_d_2include_2enum_8h.html#a09ed953cdef063487e3121c75f628df8", [
      [ "EMPTY", "_l_l_d_2include_2enum_8h.html#a09ed953cdef063487e3121c75f628df8adef899fa440ea57eadf1154afa19a01c", null ],
      [ "READY", "_l_l_d_2include_2enum_8h.html#a09ed953cdef063487e3121c75f628df8a14ee8d3264b5058080c81b38c1859850", null ],
      [ "TRANSACTION", "_l_l_d_2include_2enum_8h.html#a09ed953cdef063487e3121c75f628df8a2a9aae11593cdbad5acdcde3b1f35ab0", null ]
    ] ]
];