var _ledger_2include_2supply_8h =
[
    [ "NEXUS_TAO_LEDGER_INCLUDE_SUPPLY_H", "_ledger_2include_2supply_8h.html#a1bb0ea77d63f6ca99e9efb1b68d875ef", null ],
    [ "CompoundSubsidy", "_ledger_2include_2supply_8h.html#a91454c0330094341b6d9bc8ba8cfe35d", null ],
    [ "GetChainAge", "_ledger_2include_2supply_8h.html#a2aa1cb8eba3e49b7913bd795984464f9", null ],
    [ "GetCoinbaseReward", "_ledger_2include_2supply_8h.html#a1cb28c359191ff6a9c0e6a625d25a6a7", null ],
    [ "GetFractionalSubsidy", "_ledger_2include_2supply_8h.html#a60c36b1463fc7ea650aef16217c58a56", null ],
    [ "GetMoneySupply", "_ledger_2include_2supply_8h.html#a2e62ac0b1849a7326f9f8497f887ce1e", null ],
    [ "GetReleasedReserve", "_ledger_2include_2supply_8h.html#a6c74552781e6b66b1e6db5c0d4637306", null ],
    [ "GetSubsidy", "_ledger_2include_2supply_8h.html#abc65b9252dd64c14fdd87f63ac46a0ee", null ],
    [ "ReleaseRewards", "_ledger_2include_2supply_8h.html#acdf6aa27d9aa7b8627b1719bd48a0ecd", null ],
    [ "SubsidyInterval", "_ledger_2include_2supply_8h.html#a5b95c5dac0c769866d9db5ba9c1ecff6", null ],
    [ "decay", "_ledger_2include_2supply_8h.html#a945dae0d7a055f3ce3bfc1bc528ca205", null ]
];