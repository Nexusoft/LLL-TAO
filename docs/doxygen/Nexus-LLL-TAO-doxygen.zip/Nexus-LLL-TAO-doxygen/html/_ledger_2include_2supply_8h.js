var _ledger_2include_2supply_8h =
[
    [ "NEXUS_TAO_LEDGER_INCLUDE_SUPPLY_H", "_ledger_2include_2supply_8h.html#a1bb0ea77d63f6ca99e9efb1b68d875ef", null ],
    [ "CompoundSubsidy", "_ledger_2include_2supply_8h.html#a865c3fe02d55ff2e6da997ff4b669f64", null ],
    [ "GetChainAge", "_ledger_2include_2supply_8h.html#a2aa1cb8eba3e49b7913bd795984464f9", null ],
    [ "GetCoinbaseReward", "_ledger_2include_2supply_8h.html#aa6ee4bfe637e8a5b74cb003888730ea7", null ],
    [ "GetFractionalSubsidy", "_ledger_2include_2supply_8h.html#a7a7d1dcd4cb952523eba8f512913551d", null ],
    [ "GetMoneySupply", "_ledger_2include_2supply_8h.html#a2e62ac0b1849a7326f9f8497f887ce1e", null ],
    [ "GetReleasedReserve", "_ledger_2include_2supply_8h.html#aaabadcee6f4b95c44c2cdbe240f937c3", null ],
    [ "GetSubsidy", "_ledger_2include_2supply_8h.html#a8dde1753da5ecafe897fac2a106b15f7", null ],
    [ "ReleaseRewards", "_ledger_2include_2supply_8h.html#acdf6aa27d9aa7b8627b1719bd48a0ecd", null ],
    [ "SubsidyInterval", "_ledger_2include_2supply_8h.html#a5b95c5dac0c769866d9db5ba9c1ecff6", null ],
    [ "decay", "_ledger_2include_2supply_8h.html#afe64db38180e5a58cdb1f53883a693da", null ]
];