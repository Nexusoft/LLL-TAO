var _ledger_2stake_8cpp =
[
    [ "BlockWeight", "_ledger_2stake_8cpp.html#ae47e61b1d1af3e36dd6c125926384bb8", null ],
    [ "FindLastStake", "_ledger_2stake_8cpp.html#a68678c30754571476ccea91c35ea5ad7", null ],
    [ "GenesisWeight", "_ledger_2stake_8cpp.html#af4c881572c760aa1cb3bac8285bc3f9e", null ],
    [ "GetCoinstakeReward", "_ledger_2stake_8cpp.html#a74c416f64df376191c344b7a1dbb795e", null ],
    [ "GetCurrentThreshold", "_ledger_2stake_8cpp.html#ab8f78b2ef411748f562cf003db8ed730", null ],
    [ "GetRequiredThreshold", "_ledger_2stake_8cpp.html#af328b81220fdab0633b0ad17454cc925", null ],
    [ "GetTrustScore", "_ledger_2stake_8cpp.html#a89176c44bf2b4675e5f9cf07000a7d8f", null ],
    [ "MaxBlockAge", "_ledger_2stake_8cpp.html#a052eda6ce3c1c07c9ff76abdad4eef34", null ],
    [ "MinCoinAge", "_ledger_2stake_8cpp.html#a9ed3b0545f2360d7c76c835df189b2b8", null ],
    [ "MinStakeInterval", "_ledger_2stake_8cpp.html#aa0e5aef024307f256ca437a2aa456b58", null ],
    [ "StakeRate", "_ledger_2stake_8cpp.html#a6a432a8a5dfa8266823af001444fb1e6", null ],
    [ "TrustWeight", "_ledger_2stake_8cpp.html#a747f50c0e17ba253a7bff89cf37a2f75", null ],
    [ "TrustWeightBase", "_ledger_2stake_8cpp.html#af0c1758b7aa66fb1cba59308754d1313", null ]
];