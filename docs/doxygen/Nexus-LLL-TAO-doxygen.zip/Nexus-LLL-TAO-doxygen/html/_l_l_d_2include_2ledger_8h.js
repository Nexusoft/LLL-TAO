var _l_l_d_2include_2ledger_8h =
[
    [ "LedgerDB", "class_l_l_d_1_1_ledger_d_b.html", "class_l_l_d_1_1_ledger_d_b" ],
    [ "NEXUS_LLD_INCLUDE_LEDGER_H", "_l_l_d_2include_2ledger_8h.html#a40bbc07b60aeab11e93173288343b7c3", null ]
];