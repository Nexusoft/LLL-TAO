var _t_a_o_2_operation_2include_2enum_8h =
[
    [ "OP", "struct_t_a_o_1_1_operation_1_1_o_p.html", "struct_t_a_o_1_1_operation_1_1_o_p" ],
    [ "TYPES", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_t_y_p_e_s.html", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_t_y_p_e_s" ],
    [ "REGISTER", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_r_e_g_i_s_t_e_r.html", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_r_e_g_i_s_t_e_r" ],
    [ "CALLER", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_c_a_l_l_e_r.html", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_c_a_l_l_e_r" ],
    [ "LEDGER", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_l_e_d_g_e_r.html", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_l_e_d_g_e_r" ],
    [ "CRYPTO", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_c_r_y_p_t_o.html", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_c_r_y_p_t_o" ],
    [ "GLOBAL", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_g_l_o_b_a_l.html", "struct_t_a_o_1_1_operation_1_1_o_p_1_1_g_l_o_b_a_l" ],
    [ "NEXUS_TAO_OPERATION_INCLUDE_ENUM_H", "_t_a_o_2_operation_2include_2enum_8h.html#aa0595ea893f5d04e3cf4c858068f5a56", null ]
];