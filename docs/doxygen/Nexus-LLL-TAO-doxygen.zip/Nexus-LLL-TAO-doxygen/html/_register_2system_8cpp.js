var _register_2system_8cpp =
[
    [ "Initialize", "_register_2system_8cpp.html#a85f6fff23925626c7eb727b8524b92c6", null ]
];