var _legacy_2types_2coinbase_8h =
[
    [ "Coinbase", "class_legacy_1_1_coinbase.html", "class_legacy_1_1_coinbase" ],
    [ "NEXUS_LEGACY_TYPES_COINBASE_H", "_legacy_2types_2coinbase_8h.html#ae633ee03b91eba8c680e446c9cac2fc1", null ]
];