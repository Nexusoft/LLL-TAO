var _l_l_d_2include_2global_8h =
[
    [ "NEXUS_LLD_INCLUDE_GLOBAL_H", "_l_l_d_2include_2global_8h.html#a5137d69ee5ccf005ad130089f0c6213d", null ],
    [ "TxnAbort", "_l_l_d_2include_2global_8h.html#af121b65b6a78f59e531be0cf718000ec", null ],
    [ "TxnBegin", "_l_l_d_2include_2global_8h.html#a22290a2880a01180f23b9d35ff68cab6", null ],
    [ "TxnCommit", "_l_l_d_2include_2global_8h.html#a36efd77af9cd5ec8ccdc909f092e380a", null ],
    [ "TxnRecovery", "_l_l_d_2include_2global_8h.html#aff6fd4d38ffd0dac46b2aa47cd3c9221", null ]
];