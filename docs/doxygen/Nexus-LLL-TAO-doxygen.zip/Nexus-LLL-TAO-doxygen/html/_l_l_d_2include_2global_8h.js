var _l_l_d_2include_2global_8h =
[
    [ "NEXUS_LLD_INCLUDE_GLOBAL_H", "_l_l_d_2include_2global_8h.html#a5137d69ee5ccf005ad130089f0c6213d", null ],
    [ "Initialize", "_l_l_d_2include_2global_8h.html#a0bcdc315a0f4815abfd5f38ddfafd2f7", null ],
    [ "Shutdown", "_l_l_d_2include_2global_8h.html#a739f0805a2f074bc6bf8ee8f972d1ad1", null ],
    [ "TxnAbort", "_l_l_d_2include_2global_8h.html#afe7f20f8c65db0f7fe9aec6382122e86", null ],
    [ "TxnBegin", "_l_l_d_2include_2global_8h.html#ab981437103cf7f641509a3daf4246da0", null ],
    [ "TxnCommit", "_l_l_d_2include_2global_8h.html#a551d6077016f0a9c04c1ec02cd48ed0b", null ],
    [ "TxnRecovery", "_l_l_d_2include_2global_8h.html#aff6fd4d38ffd0dac46b2aa47cd3c9221", null ]
];