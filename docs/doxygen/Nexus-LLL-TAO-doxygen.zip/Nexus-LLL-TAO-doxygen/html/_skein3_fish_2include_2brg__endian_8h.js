var _skein3_fish_2include_2brg__endian_8h =
[
    [ "BRG_ENDIAN_H", "_skein3_fish_2include_2brg__endian_8h.html#abe17bf85ce6958fc6314f4348d5bddf5", null ],
    [ "IS_BIG_ENDIAN", "_skein3_fish_2include_2brg__endian_8h.html#a0fdc6fe49d3e76c9ed558321df1decef", null ],
    [ "IS_LITTLE_ENDIAN", "_skein3_fish_2include_2brg__endian_8h.html#a30f87dfd7349d5165f116b550c35c6ed", null ],
    [ "PLATFORM_MUST_ALIGN", "_skein3_fish_2include_2brg__endian_8h.html#a597b9bef3a54d48bd59a66749ad07640", null ]
];