var _legacy_2types_2legacy_8h =
[
    [ "LegacyBlock", "class_legacy_1_1_legacy_block.html", "class_legacy_1_1_legacy_block" ],
    [ "NEXUS_LEGACY_TYPES_LEGACY_H", "_legacy_2types_2legacy_8h.html#a7b495ec765b5b61fda5412f289896268", null ]
];