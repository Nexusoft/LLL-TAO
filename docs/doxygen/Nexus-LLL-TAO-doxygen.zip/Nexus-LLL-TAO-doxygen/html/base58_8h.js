var base58_8h =
[
    [ "CBase58Data", "classencoding_1_1_c_base58_data.html", "classencoding_1_1_c_base58_data" ],
    [ "NEXUS_UTIL_INCLUDE_BASE58_H", "base58_8h.html#a396b272c633876316c96a0f5d1b4181c", null ]
];