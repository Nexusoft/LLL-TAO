var _skein_2brg__types_8h =
[
    [ "BRG_UI16", "_skein_2brg__types_8h.html#a9c29941d9410acae54d00db8b14d7474", null ],
    [ "BRG_UI32", "_skein_2brg__types_8h.html#a8668968f5fc6842420f0a1f30055e903", null ],
    [ "BRG_UI8", "_skein_2brg__types_8h.html#aa8f288fbf2b16643aa639ec5f0e08a1f", null ],
    [ "dec_bufr_type", "_skein_2brg__types_8h.html#a290d801795408bebbc420f1782b2c844", null ],
    [ "dec_unit_type", "_skein_2brg__types_8h.html#ab29af6710b839af7ecf13eada493abd6", null ],
    [ "INT_RETURN", "_skein_2brg__types_8h.html#af808374fe222f29598b82d8c1e69efde", null ],
    [ "ptr_cast", "_skein_2brg__types_8h.html#a1e4ff8c765bc31e8c4b801e7d32f3da9", null ],
    [ "RETURN_VALUES", "_skein_2brg__types_8h.html#a6ab2e13cff777db6a91360d9cae4ee5a", null ],
    [ "ui_type", "_skein_2brg__types_8h.html#a60c9c7476b3b121bef023663aa1124f4", null ],
    [ "VOID_RETURN", "_skein_2brg__types_8h.html#af71e197a4d5c1137fdca6be3595fdc8a", null ]
];