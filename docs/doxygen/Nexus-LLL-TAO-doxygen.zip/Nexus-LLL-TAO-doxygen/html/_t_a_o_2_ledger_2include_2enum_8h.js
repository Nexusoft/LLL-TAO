var _t_a_o_2_ledger_2include_2enum_8h =
[
    [ "NEXUS_TAO_LEDGER_INCLUDE_ENUM_H", "_t_a_o_2_ledger_2include_2enum_8h.html#a741fa4fd0b3882971e0b775b8f0ca756", null ],
    [ "TRITIUM", "_t_a_o_2_ledger_2include_2enum_8h.html#aa5ef53d42477dc1a2d0deb65f89b33f4ab63bab55b2641b3a854f4185286f868b", null ],
    [ "LEGACY", "_t_a_o_2_ledger_2include_2enum_8h.html#aa5ef53d42477dc1a2d0deb65f89b33f4a6dbac2278e2588d65a22cedbabbd90b8", null ]
];