var allocators_8h =
[
    [ "secure_allocator", "structsecure__allocator.html", "structsecure__allocator" ],
    [ "rebind", "structsecure__allocator_1_1rebind.html", "structsecure__allocator_1_1rebind" ],
    [ "zero_after_free_allocator", "structzero__after__free__allocator.html", "structzero__after__free__allocator" ],
    [ "rebind", "structzero__after__free__allocator_1_1rebind.html", "structzero__after__free__allocator_1_1rebind" ],
    [ "mlock", "allocators_8h.html#ade8c15d843fd1616ef9461e8feefc383", null ],
    [ "munlock", "allocators_8h.html#abad776ff1dc3360dcedf87936512ccc7", null ],
    [ "NEXUS_UTIL_INCLUDE_ALLOCATORS_H", "allocators_8h.html#a1ec6bf82cd40b1a5ed7ba7194001f084", null ],
    [ "PAGESIZE", "allocators_8h.html#a519adc2af3ba06a8f0548b6690050a89", null ],
    [ "SecureString", "allocators_8h.html#a396ed773a5ac24aec28c8f7dc413c7ac", null ]
];