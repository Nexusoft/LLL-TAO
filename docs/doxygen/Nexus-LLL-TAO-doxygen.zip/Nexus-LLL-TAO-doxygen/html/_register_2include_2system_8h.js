var _register_2include_2system_8h =
[
    [ "NEXUS_TAO_REGISTER_INCLUDE_SYSTEM_H", "_register_2include_2system_8h.html#a216a068c0d163f7cee69240e7f5c5973", null ],
    [ "Initialize", "_register_2include_2system_8h.html#a85f6fff23925626c7eb727b8524b92c6", null ],
    [ "Reserved", "_register_2include_2system_8h.html#a8fd86640d2b9e89dce47cbab086a9990", null ]
];