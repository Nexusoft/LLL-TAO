var checkpoints_8h =
[
    [ "NEXUS_TAO_LEDGER_INCLUDE_CHECKPOINTS_H", "checkpoints_8h.html#a6f6ecc62fff6756a3d9b55cdbec33eb0", null ],
    [ "HardenCheckpoint", "checkpoints_8h.html#ac58e18aff3a6db53f000b82a380fe185", null ],
    [ "IsDescendant", "checkpoints_8h.html#a37be131e8c5b1290433535b81d93d657", null ],
    [ "IsNewTimespan", "checkpoints_8h.html#a4c2ec7c656bc0605b6c69e8de6dcd27c", null ]
];