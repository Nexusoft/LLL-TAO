var _t_a_o_2_operation_2trust_8cpp =
[
    [ "Trust", "_t_a_o_2_operation_2trust_8cpp.html#a3d3a591db2984f9f0ef0049651b73d8b", null ]
];