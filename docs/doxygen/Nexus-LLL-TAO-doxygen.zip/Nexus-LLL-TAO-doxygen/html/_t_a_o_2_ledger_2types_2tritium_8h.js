var _t_a_o_2_ledger_2types_2tritium_8h =
[
    [ "TritiumBlock", "class_t_a_o_1_1_ledger_1_1_tritium_block.html", "class_t_a_o_1_1_ledger_1_1_tritium_block" ],
    [ "NEXUS_TAO_LEDGER_TYPES_TRITIUM_H", "_t_a_o_2_ledger_2types_2tritium_8h.html#afb72485d9e717d8d1deba0c787777e7d", null ]
];