var _l_l_p_2include_2global_8h =
[
    [ "NEXUS_LLP_INCLUDE_GLOBAL_H", "_l_l_p_2include_2global_8h.html#a561947673c5f8f8c444b4d58ce1c5881", null ],
    [ "CreateMiningServer", "_l_l_p_2include_2global_8h.html#afebaa51179cf0f445814e0ba4d3fa805", null ],
    [ "CreateTAOServer", "_l_l_p_2include_2global_8h.html#ae3b23923fa5ffea139f3254a22facb84", null ],
    [ "Initialize", "_l_l_p_2include_2global_8h.html#a395efded3567d03715bd7f78e1157447", null ],
    [ "MakeConnections", "_l_l_p_2include_2global_8h.html#af1663b909e707ebcd60f7875582e72b0", null ],
    [ "Shutdown", "_l_l_p_2include_2global_8h.html#a3cdcf752b922d44a256e7fbd9d97724c", null ],
    [ "Shutdown", "_l_l_p_2include_2global_8h.html#a1a10c1fb810ca123897bce33a985726c", null ]
];