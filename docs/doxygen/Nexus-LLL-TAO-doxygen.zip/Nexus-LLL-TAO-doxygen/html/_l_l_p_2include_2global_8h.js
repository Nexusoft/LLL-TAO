var _l_l_p_2include_2global_8h =
[
    [ "NEXUS_LLP_INCLUDE_GLOBAL_H", "_l_l_p_2include_2global_8h.html#a561947673c5f8f8c444b4d58ce1c5881", null ],
    [ "CreateMiningServer", "_l_l_p_2include_2global_8h.html#adc1a4df0f3047b44ef08dc3ac3efdcd8", null ],
    [ "CreateTAOServer", "_l_l_p_2include_2global_8h.html#ac10ef3d0a956f99736bb8de8f28edf2e", null ],
    [ "MakeConnections", "_l_l_p_2include_2global_8h.html#af1663b909e707ebcd60f7875582e72b0", null ],
    [ "ShutdownServer", "_l_l_p_2include_2global_8h.html#a8ed42eb2d30503224c25b95527807767", null ]
];