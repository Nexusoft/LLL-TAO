var _legacy_2trust_8cpp =
[
    [ "BuildMigrateDebit", "_legacy_2trust_8cpp.html#a05ef0ffe9fc95b2cbae6bf8294293070", null ],
    [ "FindGenesis", "_legacy_2trust_8cpp.html#a5920cb36c96fe1c9af1d05998be212f2", null ],
    [ "FindMigratedTrustKey", "_legacy_2trust_8cpp.html#a38539944704fb157050e787fcab4036d", null ],
    [ "GetLastTrust", "_legacy_2trust_8cpp.html#ae8468732c89fa5067305db4c333bcdac", null ]
];