var _legacy_2trust_8cpp =
[
    [ "FindGenesis", "_legacy_2trust_8cpp.html#a5920cb36c96fe1c9af1d05998be212f2", null ],
    [ "GetLastTrust", "_legacy_2trust_8cpp.html#ae8468732c89fa5067305db4c333bcdac", null ]
];