var _t_a_o_2_operation_2include_2coinbase_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_COINBASE_H", "_t_a_o_2_operation_2include_2coinbase_8h.html#a494f9826a844193d442b0620b60defcb", null ],
    [ "Commit", "_t_a_o_2_operation_2include_2coinbase_8h.html#a98a33f519de479da7df17fa989536dac", null ],
    [ "Verify", "_t_a_o_2_operation_2include_2coinbase_8h.html#a25b4e3f4cee9e5af2144d718b90d09a0", null ]
];