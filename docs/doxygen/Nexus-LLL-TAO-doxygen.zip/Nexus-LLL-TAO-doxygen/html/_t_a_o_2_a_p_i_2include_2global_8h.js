var _t_a_o_2_a_p_i_2include_2global_8h =
[
    [ "NEXUS_TAO_API_INCLUDE_GLOBAL_H", "_t_a_o_2_a_p_i_2include_2global_8h.html#a598968177e5f9095eba0a4f3655bb306", null ],
    [ "Initialize", "_t_a_o_2_a_p_i_2include_2global_8h.html#a3cb04f68e4119d341bc47ea6301939f6", null ],
    [ "Shutdown", "_t_a_o_2_a_p_i_2include_2global_8h.html#a19b909d225e1b6a41cfad3880de6c5f9", null ]
];