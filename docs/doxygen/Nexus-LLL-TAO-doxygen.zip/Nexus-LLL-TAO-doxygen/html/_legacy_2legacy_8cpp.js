var _legacy_2legacy_8cpp =
[
    [ "VerifyAddress", "_legacy_2legacy_8cpp.html#a28c2163bf2964e76e948c88066dabee5", null ],
    [ "VerifyAddressList", "_legacy_2legacy_8cpp.html#ae1d3e68c06227f30bf10013df2a9a411", null ]
];