var addressbook_8h =
[
    [ "AddressBook", "class_legacy_1_1_address_book.html", "class_legacy_1_1_address_book" ],
    [ "NEXUS_LEGACY_WALLET_ADDRESSBOOK_H", "addressbook_8h.html#ae11bef3018b116cd228fad60c473e964", null ],
    [ "AddressBookMap", "addressbook_8h.html#a424e0e5233b0b8b9f3ece0313737a2c3", null ]
];