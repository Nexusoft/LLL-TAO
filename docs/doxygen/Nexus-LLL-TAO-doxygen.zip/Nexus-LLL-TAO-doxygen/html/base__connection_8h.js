var base__connection_8h =
[
    [ "BaseConnection", "class_l_l_p_1_1_base_connection.html", "class_l_l_p_1_1_base_connection" ],
    [ "NEXUS_LLP_TEMPLATES_BASE_CONNECTION_H", "base__connection_8h.html#a91707f6638cbae749332863a9f6b0cf4", null ]
];