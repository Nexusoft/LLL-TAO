var _t_a_o_2_operation_2include_2constants_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_CONSTANTS_H", "_t_a_o_2_operation_2include_2constants_8h.html#a199571a192fea273b4049909a02ad6b9", null ],
    [ "CONDITION_LIMIT_FREE", "_t_a_o_2_operation_2include_2constants_8h.html#a61aa81ab3a5ab24c09c984bb9f350a1e", null ]
];