var _l_l_d_2global_8cpp =
[
    [ "TxnAbort", "_l_l_d_2global_8cpp.html#af121b65b6a78f59e531be0cf718000ec", null ],
    [ "TxnBegin", "_l_l_d_2global_8cpp.html#a22290a2880a01180f23b9d35ff68cab6", null ],
    [ "TxnCommit", "_l_l_d_2global_8cpp.html#a36efd77af9cd5ec8ccdc909f092e380a", null ],
    [ "TxnRecovery", "_l_l_d_2global_8cpp.html#aff6fd4d38ffd0dac46b2aa47cd3c9221", null ],
    [ "legacyDB", "_l_l_d_2global_8cpp.html#a3151dd7c772000407e09bb0fe77eaebc", null ],
    [ "legDB", "_l_l_d_2global_8cpp.html#ab1b2a931b9a9ab6d23c2ece702cb1c0f", null ],
    [ "locDB", "_l_l_d_2global_8cpp.html#a7659f2c41499d1cd706323aae45676bd", null ],
    [ "regDB", "_l_l_d_2global_8cpp.html#ad649adeb94bb3d6b4105f5bfc9481bb8", null ],
    [ "trustDB", "_l_l_d_2global_8cpp.html#a0778b88c5171d70683e569ef885dd2b1", null ]
];