var _l_l_d_2global_8cpp =
[
    [ "Initialize", "_l_l_d_2global_8cpp.html#a0bcdc315a0f4815abfd5f38ddfafd2f7", null ],
    [ "Shutdown", "_l_l_d_2global_8cpp.html#a739f0805a2f074bc6bf8ee8f972d1ad1", null ],
    [ "TxnAbort", "_l_l_d_2global_8cpp.html#afe7f20f8c65db0f7fe9aec6382122e86", null ],
    [ "TxnBegin", "_l_l_d_2global_8cpp.html#ab981437103cf7f641509a3daf4246da0", null ],
    [ "TxnCommit", "_l_l_d_2global_8cpp.html#a551d6077016f0a9c04c1ec02cd48ed0b", null ],
    [ "TxnRecovery", "_l_l_d_2global_8cpp.html#aff6fd4d38ffd0dac46b2aa47cd3c9221", null ],
    [ "Contract", "_l_l_d_2global_8cpp.html#a38cf449c895b35dda52f73ee407bce2a", null ],
    [ "Ledger", "_l_l_d_2global_8cpp.html#adfce351da8bd71ef1beeba0ee8acd877", null ],
    [ "Legacy", "_l_l_d_2global_8cpp.html#a584b3da08a0f2ded60256c3e6c4cccbb", null ],
    [ "Local", "_l_l_d_2global_8cpp.html#a62183a38cf474343ab4ee617ef407856", null ],
    [ "Register", "_l_l_d_2global_8cpp.html#a7eb5846d773eba37c2c8ad792762946e", null ],
    [ "Trust", "_l_l_d_2global_8cpp.html#afc4ef8ad07c781fae735247e719bc0f1", null ]
];