var accountingentry_8h =
[
    [ "AccountingEntry", "class_legacy_1_1_accounting_entry.html", "class_legacy_1_1_accounting_entry" ],
    [ "NEXUS_LEGACY_WALLET_ACCOUNTINGENTRY_H", "accountingentry_8h.html#abfb465463bcff20dde26594cf9b213d6", null ]
];