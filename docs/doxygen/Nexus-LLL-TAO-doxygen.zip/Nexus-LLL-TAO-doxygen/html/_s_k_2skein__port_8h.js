var _s_k_2skein__port_8h =
[
    [ "_SKEIN_PORT_H_", "_s_k_2skein__port_8h.html#afe0962ba6b72bddc131407e95d1586b6", null ],
    [ "RotL_64", "_s_k_2skein__port_8h.html#acbb729a28f876230827e8af03ec24cc0", null ],
    [ "SKEIN_NEED_SWAP", "_s_k_2skein__port_8h.html#a700c95d42bd6a9161fa0aa0216e901d1", null ],
    [ "Skein_Swap64", "_s_k_2skein__port_8h.html#a8f5a89e88f6b262b62433cd49ac8b39a", null ],
    [ "u08b_t", "_s_k_2skein__port_8h.html#aaea2647f2780836a508ecd6dbefe4a9e", null ],
    [ "u64b_t", "_s_k_2skein__port_8h.html#a37faf6b991adade06ae44c4cdcde667b", null ],
    [ "uint_t", "_s_k_2skein__port_8h.html#a36e75e4cb542ce4aa13a3cd5da3d5fea", null ],
    [ "Skein_Get64_LSB_First", "_s_k_2skein__port_8h.html#a60dedd962bbc4a3554a1a94df43c5b5a", null ],
    [ "Skein_Put64_LSB_First", "_s_k_2skein__port_8h.html#a0e7894a26c546e778d128dd54f931839", null ]
];