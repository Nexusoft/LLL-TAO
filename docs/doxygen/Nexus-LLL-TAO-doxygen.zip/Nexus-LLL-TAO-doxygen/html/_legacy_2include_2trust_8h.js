var _legacy_2include_2trust_8h =
[
    [ "NEXUS_LEGACY_INCLUDE_TRUST_H", "_legacy_2include_2trust_8h.html#a20ab74d6e688987cff5f73da757ca2a5", null ],
    [ "BuildMigrateDebit", "_legacy_2include_2trust_8h.html#a05ef0ffe9fc95b2cbae6bf8294293070", null ],
    [ "FindGenesis", "_legacy_2include_2trust_8h.html#a5920cb36c96fe1c9af1d05998be212f2", null ],
    [ "FindMigratedTrustKey", "_legacy_2include_2trust_8h.html#a38539944704fb157050e787fcab4036d", null ],
    [ "GetLastTrust", "_legacy_2include_2trust_8h.html#ae8468732c89fa5067305db4c333bcdac", null ]
];