var _legacy_2include_2trust_8h =
[
    [ "NEXUS_LEGACY_INCLUDE_TRUST_H", "_legacy_2include_2trust_8h.html#a20ab74d6e688987cff5f73da757ca2a5", null ],
    [ "FindGenesis", "_legacy_2include_2trust_8h.html#a5920cb36c96fe1c9af1d05998be212f2", null ],
    [ "GetLastTrust", "_legacy_2include_2trust_8h.html#ae8468732c89fa5067305db4c333bcdac", null ]
];