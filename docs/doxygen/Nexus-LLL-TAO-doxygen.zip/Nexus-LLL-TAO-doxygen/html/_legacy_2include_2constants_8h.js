var _legacy_2include_2constants_8h =
[
    [ "NEXUS_LEGACY_INCLUDE_CONSTANTS_H", "_legacy_2include_2constants_8h.html#a96540afb8e85352e546f0913b0b3ec3c", null ],
    [ "bnFalse", "_legacy_2include_2constants_8h.html#a783c27d2507521967f09ea893f0d438f", null ],
    [ "bnOne", "_legacy_2include_2constants_8h.html#a214f88db4fae696e2526bdc0bc1eb8a2", null ],
    [ "bnTrue", "_legacy_2include_2constants_8h.html#ac0860d973f48c5371b758317ba5e4750", null ],
    [ "bnZero", "_legacy_2include_2constants_8h.html#abe2dbc5c4cea0b66a6d442975200efd8", null ],
    [ "vchFalse", "_legacy_2include_2constants_8h.html#ac23c94dd262f24275dc62083093595f9", null ],
    [ "vchTrue", "_legacy_2include_2constants_8h.html#ac25c6a793b45526f10738606ad975581", null ],
    [ "vchZero", "_legacy_2include_2constants_8h.html#a25da194230f35b060dc0b516161cabdb", null ],
    [ "nMaxNumSize", "_legacy_2include_2constants_8h.html#abc2649cd3a72cd7d70a750906c627a85", null ],
    [ "strMessageMagic", "_legacy_2include_2constants_8h.html#ab19f87826d596ebb4b0594a741a8be01", null ]
];