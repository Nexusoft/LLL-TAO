var blamka_round_opt_8h =
[
    [ "_mm_roti_epi64", "blamka-round-opt_8h.html#a4b2c5cdf0a7ce77d4b1acfe1b4fc7883", null ],
    [ "BLAKE2_ROUND", "blamka-round-opt_8h.html#a49f46571273cbbead52b2085e973c5ed", null ],
    [ "DIAGONALIZE", "blamka-round-opt_8h.html#a4f5153b33e2d6c8a2a0b5084efa1fe0e", null ],
    [ "G1", "blamka-round-opt_8h.html#ac5393222f6177ce751b9f0426f88cfa7", null ],
    [ "G2", "blamka-round-opt_8h.html#aa720bd2ea16e8f47866b15c03e53444d", null ],
    [ "UNDIAGONALIZE", "blamka-round-opt_8h.html#a8c3e6d429c117a457d672f91bba5343c", null ]
];