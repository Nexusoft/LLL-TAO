var _legacy_2types_2address_8h =
[
    [ "NexusAddress", "class_legacy_1_1_nexus_address.html", "class_legacy_1_1_nexus_address" ],
    [ "NEXUS_LEGACY_TYPES_ADDRESS_H", "_legacy_2types_2address_8h.html#ab3f9d49928a9b08e5946a374e7918aa5", null ]
];