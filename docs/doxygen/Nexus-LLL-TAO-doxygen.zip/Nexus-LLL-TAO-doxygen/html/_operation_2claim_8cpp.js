var _operation_2claim_8cpp =
[
    [ "Claim", "_operation_2claim_8cpp.html#a267db2593d2ec03bc62d9cf74b8e3ccb", null ]
];