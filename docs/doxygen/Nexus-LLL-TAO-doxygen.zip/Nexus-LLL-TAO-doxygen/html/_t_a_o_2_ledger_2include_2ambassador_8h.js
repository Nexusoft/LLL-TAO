var _t_a_o_2_ledger_2include_2ambassador_8h =
[
    [ "NEXUS_TAO_LEDGER_INCLUDE_AMBASSADOR_H", "_t_a_o_2_ledger_2include_2ambassador_8h.html#acc54fede72feb1e4e5354b24b3c448bc", null ],
    [ "AMBASSADOR", "_t_a_o_2_ledger_2include_2ambassador_8h.html#ae3b8768a154eaf9d082a82a27cb22be4", null ],
    [ "AMBASSADOR_PAYOUT_THRESHOLD", "_t_a_o_2_ledger_2include_2ambassador_8h.html#aa9f9dd7ffdd2dd1eca5d2bd1cfa70f54", null ],
    [ "AMBASSADOR_PAYOUT_THRESHOLD_TESTNET", "_t_a_o_2_ledger_2include_2ambassador_8h.html#aade7d228a8e112f6105b82ef12e83a3a", null ],
    [ "AMBASSADOR_TESTNET", "_t_a_o_2_ledger_2include_2ambassador_8h.html#a17ff8cc3856890fe1ef182332c74e592", null ]
];