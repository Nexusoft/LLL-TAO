var _l_l_p_2types_2legacy_8h =
[
    [ "LegacyNode", "class_l_l_p_1_1_legacy_node.html", "class_l_l_p_1_1_legacy_node" ],
    [ "NEXUS_LLP_TYPES_LEGACY_H", "_l_l_p_2types_2legacy_8h.html#a6de6e68b84d6e23f0dc3aded6f26af24", null ]
];