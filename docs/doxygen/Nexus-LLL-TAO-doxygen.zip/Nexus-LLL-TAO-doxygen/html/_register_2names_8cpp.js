var _register_2names_8cpp =
[
    [ "GetNameRegister", "_register_2names_8cpp.html#adf4ca4b90a92b33d09ebefebb23de50d", null ],
    [ "GetNamespaceRegister", "_register_2names_8cpp.html#a9fd498eb769fecba808f5e2ed83882b9", null ]
];