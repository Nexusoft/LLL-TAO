var _l_l_p_2lisp_8cpp =
[
    [ "GetEIDs", "_l_l_p_2lisp_8cpp.html#ae3586cb13a5c4ec1908688a6c8b7a5bd", null ],
    [ "LispersAPIRequest", "_l_l_p_2lisp_8cpp.html#af8619428cbbdd9435f27be1a5584eb5d", null ]
];