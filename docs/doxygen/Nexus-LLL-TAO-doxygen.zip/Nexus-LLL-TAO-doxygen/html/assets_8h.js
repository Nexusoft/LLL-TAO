var assets_8h =
[
    [ "Assets", "class_t_a_o_1_1_a_p_i_1_1_assets.html", "class_t_a_o_1_1_a_p_i_1_1_assets" ],
    [ "NEXUS_TAO_API_INCLUDE_ASSETS_H", "assets_8h.html#a18acb949f85bb43ccdf00bbbaf978251", null ]
];