var append_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_APPEND_H", "append_8h.html#a6cbdfb31a7375f55fa7655ca98bf694e", null ],
    [ "Commit", "append_8h.html#acfc2e943564133fc91f81cd6ea3e1998", null ],
    [ "Execute", "append_8h.html#af3238206127604c82bc2b8e36d1f78fb", null ],
    [ "Verify", "append_8h.html#a699820ed980057fb083e6dfedb99d726", null ]
];