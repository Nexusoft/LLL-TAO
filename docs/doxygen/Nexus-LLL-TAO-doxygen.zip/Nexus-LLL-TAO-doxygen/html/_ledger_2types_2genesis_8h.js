var _ledger_2types_2genesis_8h =
[
    [ "Genesis", "class_t_a_o_1_1_ledger_1_1_genesis.html", "class_t_a_o_1_1_ledger_1_1_genesis" ],
    [ "NEXUS_TAO_LEDGER_TYPES_GENESIS_H", "_ledger_2types_2genesis_8h.html#a557505a00e27a4b81d6729408450d8aa", null ]
];