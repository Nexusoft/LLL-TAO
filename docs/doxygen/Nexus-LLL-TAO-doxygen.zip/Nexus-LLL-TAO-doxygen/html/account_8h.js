var account_8h =
[
    [ "Account", "class_legacy_1_1_account.html", "class_legacy_1_1_account" ],
    [ "NEXUS_LEGACY_TYPES_ACCOUNT_H", "account_8h.html#a9551244138f0c0b8c15576c5169974c1", null ]
];