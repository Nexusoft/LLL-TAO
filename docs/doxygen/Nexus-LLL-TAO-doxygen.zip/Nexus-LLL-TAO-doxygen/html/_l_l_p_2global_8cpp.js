var _l_l_p_2global_8cpp =
[
    [ "CreateMiningServer", "_l_l_p_2global_8cpp.html#afebaa51179cf0f445814e0ba4d3fa805", null ],
    [ "Initialize", "_l_l_p_2global_8cpp.html#a395efded3567d03715bd7f78e1157447", null ],
    [ "Shutdown", "_l_l_p_2global_8cpp.html#a3cdcf752b922d44a256e7fbd9d97724c", null ],
    [ "API_SERVER", "_l_l_p_2global_8cpp.html#a67ef4ed7f87199855c370bcdd57b490f", null ],
    [ "LEGACY_SERVER", "_l_l_p_2global_8cpp.html#a9cf9b6efcd02e64342a15f778c8bb367", null ],
    [ "MINING_SERVER", "_l_l_p_2global_8cpp.html#a361f631b69adaad03db4561814b6533e", null ],
    [ "RPC_SERVER", "_l_l_p_2global_8cpp.html#a76e0cb7fe719c4106b017542c2992843", null ],
    [ "SESSION_ID", "_l_l_p_2global_8cpp.html#a60c73e249000c9ba00a43ed00a338097", null ],
    [ "TIME_SERVER", "_l_l_p_2global_8cpp.html#a93d9ac683aabfd65827687f2dce9ac45", null ],
    [ "TRITIUM_SERVER", "_l_l_p_2global_8cpp.html#a5fbbba0917cbb5d01a8cc7a69d3697df", null ]
];