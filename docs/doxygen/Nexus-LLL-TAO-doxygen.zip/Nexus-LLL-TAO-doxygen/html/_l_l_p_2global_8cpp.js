var _l_l_p_2global_8cpp =
[
    [ "CORE_SERVER", "_l_l_p_2global_8cpp.html#a6bff18eb8b8219cec7952e7e181c959b", null ],
    [ "LEGACY_MINING_SERVER", "_l_l_p_2global_8cpp.html#ae89adfd93b48f5341974a0cc5e4e64e8", null ],
    [ "LEGACY_SERVER", "_l_l_p_2global_8cpp.html#a9cf9b6efcd02e64342a15f778c8bb367", null ],
    [ "RPC_SERVER", "_l_l_p_2global_8cpp.html#a76e0cb7fe719c4106b017542c2992843", null ],
    [ "TIME_SERVER", "_l_l_p_2global_8cpp.html#a93d9ac683aabfd65827687f2dce9ac45", null ],
    [ "TRITIUM_MINING_SERVER", "_l_l_p_2global_8cpp.html#a281e2b508068accffcaada03e2e1a3ca", null ],
    [ "TRITIUM_SERVER", "_l_l_p_2global_8cpp.html#a5fbbba0917cbb5d01a8cc7a69d3697df", null ]
];