var base__minter_8h =
[
    [ "StakeMinter", "class_t_a_o_1_1_ledger_1_1_stake_minter.html", "class_t_a_o_1_1_ledger_1_1_stake_minter" ],
    [ "NEXUS_TAO_LEDGER_TYPES_BASE_MINTER_H", "base__minter_8h.html#ac8db93f25d36789f7fffc688ca43cc98", null ]
];