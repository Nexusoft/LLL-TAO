var class_legacy_1_1_address_book =
[
    [ "AddressBook", "class_legacy_1_1_address_book.html#a2704c8eab0749cbc34cada94ded95cd5", null ],
    [ "AvailableAddresses", "class_legacy_1_1_address_book.html#a479afc9073be199794a6463a63c05775", null ],
    [ "BalanceByAccount", "class_legacy_1_1_address_book.html#a448d2393581ddf2d1f8a7173d2fd596f", null ],
    [ "DelAddressBookName", "class_legacy_1_1_address_book.html#a31d6c5b2a220e4ad252e643f6b49af66", null ],
    [ "GetAccountAddress", "class_legacy_1_1_address_book.html#a5f0ac4a51926681081d2ce552692de3b", null ],
    [ "GetAddressBookMap", "class_legacy_1_1_address_book.html#a56798722186cb63039a5901086adb774", null ],
    [ "GetAddressBookName", "class_legacy_1_1_address_book.html#abb5f922ec1ecdbf9ecb33a3749211b3e", null ],
    [ "HasAddress", "class_legacy_1_1_address_book.html#a25b1acf525621242d5c58a895fb308fb", null ],
    [ "SetAddressBookName", "class_legacy_1_1_address_book.html#a2650e8b9a7868a630f7919d3c4f70a3b", null ],
    [ "WalletDB", "class_legacy_1_1_address_book.html#a5003a87231647e365602815a154a9980", null ]
];