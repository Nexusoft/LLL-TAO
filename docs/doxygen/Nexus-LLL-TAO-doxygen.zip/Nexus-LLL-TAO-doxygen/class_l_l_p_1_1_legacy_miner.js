var class_l_l_p_1_1_legacy_miner =
[
    [ "LegacyMiner", "class_l_l_p_1_1_legacy_miner.html#a4c8a434ae7e2f7c6cfd685b64a1851d1", null ],
    [ "LegacyMiner", "class_l_l_p_1_1_legacy_miner.html#a1e15244bdd0434e36e084f1848e4fb78", null ],
    [ "LegacyMiner", "class_l_l_p_1_1_legacy_miner.html#a2d671383811324245d9d41a5763c1b08", null ],
    [ "~LegacyMiner", "class_l_l_p_1_1_legacy_miner.html#a5cd709e0da1db2ef0507ba273c258ea1", null ],
    [ "SerializeBlock", "class_l_l_p_1_1_legacy_miner.html#ad2498d749938c49dd4ed1ed990b2d981", null ]
];