var _l_l_p_2legacy_8cpp =
[
    [ "nAsked", "_l_l_p_2legacy_8cpp.html#a84e694ecacc2195dd0d6602140cc8052", null ],
    [ "SwitchNode", "_l_l_p_2legacy_8cpp.html#a024a9606294d967f0fe2cd1bb1e3a3d7", null ],
    [ "mapConnectedSessions", "_l_l_p_2legacy_8cpp.html#afeb8ad781be807369df14cf09e3377df", null ],
    [ "mapLegacyOrphans", "_l_l_p_2legacy_8cpp.html#a638fb84b4bbf81ebe20546175bbf9630", null ],
    [ "ORPHAN_MUTEX", "_l_l_p_2legacy_8cpp.html#a19513d2dc8f4df77b0c4ef78402cc6cf", null ],
    [ "PROCESSING_MUTEX", "_l_l_p_2legacy_8cpp.html#ad870176d0975eb4112510a433b50603b", null ],
    [ "SESSIONS_MUTEX", "_l_l_p_2legacy_8cpp.html#a1939a95244d96eb3da2b0fa79410ad86", null ]
];