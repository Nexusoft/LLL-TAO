var class_legacy_1_1_nexus_address =
[
    [ "NexusAddress", "class_legacy_1_1_nexus_address.html#ae1bc952a34001f185d50953cf9e109c7", null ],
    [ "NexusAddress", "class_legacy_1_1_nexus_address.html#af82de8ddf312f41f2db77a8b1d259378", null ],
    [ "NexusAddress", "class_legacy_1_1_nexus_address.html#a8371a4552e942e056480b81d38fc92be", null ],
    [ "NexusAddress", "class_legacy_1_1_nexus_address.html#ab10877aca17ef03b5c8c3a9b29c80b77", null ],
    [ "NexusAddress", "class_legacy_1_1_nexus_address.html#ab10584c91e645a9c3e78ecbc28865b4a", null ],
    [ "GetHash256", "class_legacy_1_1_nexus_address.html#a408a1abf4dbfa1b365c93244ef928f9e", null ],
    [ "IsScript", "class_legacy_1_1_nexus_address.html#a01981bab08971f85f7be68d677009e84", null ],
    [ "IsValid", "class_legacy_1_1_nexus_address.html#a6415f95f532f797fcb9b5f5748aa66a1", null ],
    [ "SetHash256", "class_legacy_1_1_nexus_address.html#ad6fd0392d8d76a4fa033278e614b14a5", null ],
    [ "SetPubKey", "class_legacy_1_1_nexus_address.html#a522ba81bbbc4b3dcc565d9c56273d54a", null ],
    [ "SetScriptHash256", "class_legacy_1_1_nexus_address.html#a1a445e37fa668209d3dbd608b4f6d2c5", null ]
];