var _l_l_d_2include_2enum_8h =
[
    [ "NEXUS_LLD_INCLUDE_ENUM_H", "_l_l_d_2include_2enum_8h.html#a6bcc61986fc7dd510a7322a6df19d6d5", null ],
    [ "APPEND", "_l_l_d_2include_2enum_8h.html#ae1738a1980f0d946d8e0d14c58c52d95a2cd278a8addc60e705076db5baa985b4", null ],
    [ "READONLY", "_l_l_d_2include_2enum_8h.html#ae1738a1980f0d946d8e0d14c58c52d95aad35b7c697085113cbaef1751d61d81a", null ],
    [ "CREATE", "_l_l_d_2include_2enum_8h.html#ae1738a1980f0d946d8e0d14c58c52d95a8cae5d8a78f62fbabf92a4cdc9e80da7", null ],
    [ "WRITE", "_l_l_d_2include_2enum_8h.html#ae1738a1980f0d946d8e0d14c58c52d95a396b72172d85f9fcee1b57d4d8ff026e", null ],
    [ "FORCE", "_l_l_d_2include_2enum_8h.html#ae1738a1980f0d946d8e0d14c58c52d95add9b825a15b30372fc288368962c9952", null ],
    [ "EMPTY", "_l_l_d_2include_2enum_8h.html#ac2680f6977f81c27b5e4c2f438a4d7b8ad96e2dd77e65c077bbe71eccb4d839f0", null ],
    [ "READY", "_l_l_d_2include_2enum_8h.html#ac2680f6977f81c27b5e4c2f438a4d7b8a31bce9d8fcb33e28bf3a73f58ff2bd70", null ],
    [ "TRANSACTION", "_l_l_d_2include_2enum_8h.html#ac2680f6977f81c27b5e4c2f438a4d7b8a160b84d31ec4a1d6b4f0d4d5dfa5a4f9", null ]
];