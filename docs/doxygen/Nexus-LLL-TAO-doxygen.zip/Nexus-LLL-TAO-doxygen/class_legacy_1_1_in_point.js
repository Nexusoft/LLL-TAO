var class_legacy_1_1_in_point =
[
    [ "InPoint", "class_legacy_1_1_in_point.html#a6022f5768b1741be622d941d8d6915c7", null ],
    [ "InPoint", "class_legacy_1_1_in_point.html#a4e5544c24db6bd3d3b9ba71d93bbb6a9", null ],
    [ "IsNull", "class_legacy_1_1_in_point.html#a8dbc8ba4c378299eddc769991a37e0ea", null ],
    [ "SetNull", "class_legacy_1_1_in_point.html#afa1339386348e399e0c54ee3245e3aa9", null ],
    [ "n", "class_legacy_1_1_in_point.html#a5b12243ad64c7fdc0a47bd41e5615ea2", null ],
    [ "ptx", "class_legacy_1_1_in_point.html#a6a43312722624bd15e39b5630dd9c8df", null ]
];