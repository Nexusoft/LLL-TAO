var class_l_l_d_1_1_legacy_d_b =
[
    [ "LegacyDB", "class_l_l_d_1_1_legacy_d_b.html#aadb6a774abac57b24a36b15515b4afa6", null ],
    [ "EraseSpend", "class_l_l_d_1_1_legacy_d_b.html#af965ab6e5bcb2319926ece21b9257c89", null ],
    [ "EraseTx", "class_l_l_d_1_1_legacy_d_b.html#aabafd6f919724e1e2fbfbe6100984bf6", null ],
    [ "HasTx", "class_l_l_d_1_1_legacy_d_b.html#aa6fd04d39f7ec4aaf2ded2302b194fda", null ],
    [ "IsSpent", "class_l_l_d_1_1_legacy_d_b.html#a504a2398e635ad862eb941c6fd6d7999", null ],
    [ "ReadTx", "class_l_l_d_1_1_legacy_d_b.html#a203ffe17dd495ea7e7438255113a03e7", null ],
    [ "WriteSpend", "class_l_l_d_1_1_legacy_d_b.html#abfc7a23ff8b945d5d3e617744a80df02", null ],
    [ "WriteTx", "class_l_l_d_1_1_legacy_d_b.html#ad4beefb75ad4d95bdf5e646711be1c91", null ]
];