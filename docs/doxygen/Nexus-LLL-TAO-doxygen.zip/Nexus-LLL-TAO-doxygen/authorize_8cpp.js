var authorize_8cpp =
[
    [ "Authorize", "authorize_8cpp.html#aec97e5535ed4f47c585184022241d8ff", null ]
];