var _l_l_p_2include_2global_8h =
[
    [ "NEXUS_LLP_INCLUDE_GLOBAL_H", "_l_l_p_2include_2global_8h.html#a561947673c5f8f8c444b4d58ce1c5881", null ],
    [ "LEGACY_SERVER", "_l_l_p_2include_2global_8h.html#a9cf9b6efcd02e64342a15f778c8bb367", null ],
    [ "TIME_SERVER", "_l_l_p_2include_2global_8h.html#a93d9ac683aabfd65827687f2dce9ac45", null ],
    [ "TRITIUM_SERVER", "_l_l_p_2include_2global_8h.html#a5fbbba0917cbb5d01a8cc7a69d3697df", null ]
];