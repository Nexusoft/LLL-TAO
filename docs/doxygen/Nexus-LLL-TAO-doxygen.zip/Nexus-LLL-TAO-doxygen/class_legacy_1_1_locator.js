var class_legacy_1_1_locator =
[
    [ "Locator", "class_legacy_1_1_locator.html#a322b9c8f5fd6d5cb2df75661aca19744", null ],
    [ "Locator", "class_legacy_1_1_locator.html#a33676020d6761ff176c54b8bf2b30443", null ],
    [ "Locator", "class_legacy_1_1_locator.html#a186b2bb66c751ad54d7c604c754aec16", null ],
    [ "IMPLEMENT_SERIALIZE", "class_legacy_1_1_locator.html#abe972fe0f377864872d46109c21a4e1f", null ],
    [ "IsNull", "class_legacy_1_1_locator.html#a003225aa31c0fd324031e1ebe3fe3ce5", null ],
    [ "Set", "class_legacy_1_1_locator.html#a335c37d2bf1819569ac8e59c0defa1c0", null ],
    [ "SetNull", "class_legacy_1_1_locator.html#a2c6ad2490c0b1e7a0acc0adb77e5ff61", null ],
    [ "vHave", "class_legacy_1_1_locator.html#ad1a7bbf309a4b4c750178372f7044c26", null ]
];