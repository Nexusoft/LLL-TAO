var _keccak_sponge_8h =
[
    [ "Keccak_SpongeInstanceStruct", "struct_keccak___sponge_instance_struct.html", "struct_keccak___sponge_instance_struct" ],
    [ "ALIGN", "_keccak_sponge_8h.html#ae4ff5a07c6ff43ed11a3887ef7d524f2", null ],
    [ "Keccak_SpongeInstance", "_keccak_sponge_8h.html#a41935c617a6fe9720926402f2a15fef6", null ],
    [ "Keccak_SpongeAbsorb", "_keccak_sponge_8h.html#ac2f32cf46ef86d8aa33e80f499098643", null ],
    [ "Keccak_SpongeAbsorbLastFewBits", "_keccak_sponge_8h.html#a008de0940e36a70004be144114275963", null ],
    [ "Keccak_SpongeInitialize", "_keccak_sponge_8h.html#a34cb24ce43f7d8629de20ac6979afc8b", null ],
    [ "Keccak_SpongeSqueeze", "_keccak_sponge_8h.html#aa6204a273a53356ce8422558298cae92", null ]
];