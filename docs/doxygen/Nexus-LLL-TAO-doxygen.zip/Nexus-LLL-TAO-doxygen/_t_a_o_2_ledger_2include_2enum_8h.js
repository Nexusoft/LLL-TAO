var _t_a_o_2_ledger_2include_2enum_8h =
[
    [ "TRITIUM", "_t_a_o_2_ledger_2include_2enum_8h.html#ad39f3deef6b4abb4f369b035775230b5ab63bab55b2641b3a854f4185286f868b", null ],
    [ "LEGACY", "_t_a_o_2_ledger_2include_2enum_8h.html#ad39f3deef6b4abb4f369b035775230b5a6dbac2278e2588d65a22cedbabbd90b8", null ]
];