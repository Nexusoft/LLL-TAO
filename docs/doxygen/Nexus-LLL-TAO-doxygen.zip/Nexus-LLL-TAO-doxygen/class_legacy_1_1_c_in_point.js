var class_legacy_1_1_c_in_point =
[
    [ "CInPoint", "class_legacy_1_1_c_in_point.html#a1e9731c38844694e80e9d6131a471ce8", null ],
    [ "CInPoint", "class_legacy_1_1_c_in_point.html#a935b9167ee3bc823414c29f87e01461d", null ],
    [ "IsNull", "class_legacy_1_1_c_in_point.html#a2d3a149752397dbc12e1719f6f0a4c61", null ],
    [ "SetNull", "class_legacy_1_1_c_in_point.html#ade40bc6844ad3603c892d5a76d1d129d", null ],
    [ "n", "class_legacy_1_1_c_in_point.html#aac0379f7285ed47d50930c50a7fce3cd", null ],
    [ "ptx", "class_legacy_1_1_c_in_point.html#a05d9fed5d6212c79112f9e32b0486e5d", null ]
];