var _legacy_2include_2create_8h =
[
    [ "AddTransactions", "_legacy_2include_2create_8h.html#ae395a948d048f527567a1a53f89765c5", null ],
    [ "CheckWork", "_legacy_2include_2create_8h.html#ad3966eee9aac039fe3b9b033e1a336b3", null ],
    [ "CreateCoinbaseTransaction", "_legacy_2include_2create_8h.html#a908bac0a677e230bb15cf6a2037c6baa", null ],
    [ "CreateCoinstakeTransaction", "_legacy_2include_2create_8h.html#a114cd502b085d2ce663f0fc2dc51abc2", null ],
    [ "CreateLegacyBlock", "_legacy_2include_2create_8h.html#a1e306d78862ccf5bffab8a0a9a8f7180", null ],
    [ "SignBlock", "_legacy_2include_2create_8h.html#aac4b1b8466dab4f93a630616f0d1a832", null ]
];