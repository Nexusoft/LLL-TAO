var _t_a_o_2_ledger_2include_2trust_8h =
[
    [ "FindGenesis", "_t_a_o_2_ledger_2include_2trust_8h.html#aabd548eb11b56086f243f17295f5441b", null ],
    [ "GetLastTrust", "_t_a_o_2_ledger_2include_2trust_8h.html#ac06431793aa553945018ec8e4df4cb19", null ]
];