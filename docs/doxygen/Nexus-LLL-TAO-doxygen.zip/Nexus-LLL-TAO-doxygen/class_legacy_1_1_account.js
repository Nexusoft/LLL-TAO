var class_legacy_1_1_account =
[
    [ "Account", "class_legacy_1_1_account.html#aa9d23b52075e2dcc8c6b99744a2e4e23", null ],
    [ "SetNull", "class_legacy_1_1_account.html#a88b29f6dd40e7d6ab149f39a1954bc6c", null ],
    [ "vchPubKey", "class_legacy_1_1_account.html#a55aeba3f8b4647e6a2b1732515b5e473", null ]
];