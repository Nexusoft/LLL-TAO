var class_legacy_1_1_legacy_block =
[
    [ "LegacyBlock", "class_legacy_1_1_legacy_block.html#a813c0c3a3fd496e87b66bef857bb1698", null ],
    [ "LegacyBlock", "class_legacy_1_1_legacy_block.html#a48006b30695a01268c8d758a3c8601d6", null ],
    [ "Accept", "class_legacy_1_1_legacy_block.html#a1b91fe17e14bbaac125895584bf63f0a", null ],
    [ "BlockAge", "class_legacy_1_1_legacy_block.html#a2f927ebe1353fa33529f9fcfdb73cdd9", null ],
    [ "Check", "class_legacy_1_1_legacy_block.html#aebfeceea65d72f703bc162410cfe1716", null ],
    [ "CheckStake", "class_legacy_1_1_legacy_block.html#a8d67b9addc6ed8285623ea7b6936eb7b", null ],
    [ "IMPLEMENT_SERIALIZE", "class_legacy_1_1_legacy_block.html#a0435b536e864556202d79b107160b5bd", null ],
    [ "print", "class_legacy_1_1_legacy_block.html#aa5cdcda6b4c70113eebd3f192ad05559", null ],
    [ "StakeHash", "class_legacy_1_1_legacy_block.html#a1b984a51f4a9dd25513321c65befc444", null ],
    [ "ToString", "class_legacy_1_1_legacy_block.html#a6db3b07468e47370da44f7b005839322", null ],
    [ "TrustScore", "class_legacy_1_1_legacy_block.html#ae78d0f605534240dbef5f8627b1e7469", null ],
    [ "VerifyStake", "class_legacy_1_1_legacy_block.html#acf59875ff4a0ae0e0045c2abd19f4e1c", null ],
    [ "vtx", "class_legacy_1_1_legacy_block.html#aa40794f441d8864cb404d4e67a4c0617", null ]
];