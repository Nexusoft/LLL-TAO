var _ledger_2trust_8cpp =
[
    [ "FindGenesis", "_ledger_2trust_8cpp.html#aabd548eb11b56086f243f17295f5441b", null ],
    [ "GetLastTrust", "_ledger_2trust_8cpp.html#ac06431793aa553945018ec8e4df4cb19", null ]
];