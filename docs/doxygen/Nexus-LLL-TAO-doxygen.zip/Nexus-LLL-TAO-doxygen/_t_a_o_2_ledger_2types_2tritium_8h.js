var _t_a_o_2_ledger_2types_2tritium_8h =
[
    [ "TritiumBlock", "class_t_a_o_1_1_ledger_1_1_tritium_block.html", "class_t_a_o_1_1_ledger_1_1_tritium_block" ],
    [ "TYPE", "_t_a_o_2_ledger_2types_2tritium_8h.html#a68f88c405c18d112ab043524217d02eb", [
      [ "LEGACY_TX", "_t_a_o_2_ledger_2types_2tritium_8h.html#a68f88c405c18d112ab043524217d02eba791ace9e85583a47d809ed4e149192d8", null ],
      [ "TRITIUM_TX", "_t_a_o_2_ledger_2types_2tritium_8h.html#a68f88c405c18d112ab043524217d02eba8e5dc2e00fb00a1d6a665fab3ec10048", null ],
      [ "CHECKPOINT", "_t_a_o_2_ledger_2types_2tritium_8h.html#a68f88c405c18d112ab043524217d02eba35f130805f9d23ddc0c631da18feac3b", null ]
    ] ]
];