var class_l_l_p_1_1_legacy_address =
[
    [ "LegacyAddress", "class_l_l_p_1_1_legacy_address.html#a63eb3c6ea3db1120a0e391980bd1b6e1", null ],
    [ "LegacyAddress", "class_l_l_p_1_1_legacy_address.html#a3707624d9e26323aad0b240a0c3b8fe8", null ],
    [ "LegacyAddress", "class_l_l_p_1_1_legacy_address.html#a5cdfa48236dd47876340cb8891d74aa2", null ],
    [ "~LegacyAddress", "class_l_l_p_1_1_legacy_address.html#a816af8630138923e52495c964304f5e9", null ],
    [ "IMPLEMENT_SERIALIZE", "class_l_l_p_1_1_legacy_address.html#abeb329c4798a7af81c4a6cc0f2ac854d", null ],
    [ "operator=", "class_l_l_p_1_1_legacy_address.html#aff5a1691e3f415b68f3a521f0d552168", null ],
    [ "nLastTry", "class_l_l_p_1_1_legacy_address.html#a857e1432fea9e9d52872ce5b081da1af", null ],
    [ "nServices", "class_l_l_p_1_1_legacy_address.html#a24920bea3c78772322840ee2361c859b", null ],
    [ "nTime", "class_l_l_p_1_1_legacy_address.html#a893335a5d36c56d50543064a634a60d5", null ]
];