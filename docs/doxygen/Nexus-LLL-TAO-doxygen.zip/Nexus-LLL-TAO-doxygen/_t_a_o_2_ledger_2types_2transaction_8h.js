var _t_a_o_2_ledger_2types_2transaction_8h =
[
    [ "Transaction", "class_t_a_o_1_1_ledger_1_1_transaction.html", "class_t_a_o_1_1_ledger_1_1_transaction" ],
    [ "NEXUS_TAO_LEDGER_TYPES_TRANSACTION_H", "_t_a_o_2_ledger_2types_2transaction_8h.html#a1cbbce8999b23627f208edabbccb2d01", null ]
];