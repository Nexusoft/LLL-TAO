var _l_l_p_2packets_2legacy_8h =
[
    [ "LegacyPacket", "class_l_l_p_1_1_legacy_packet.html", "class_l_l_p_1_1_legacy_packet" ],
    [ "MESSAGE_START_MAINNET", "_l_l_p_2packets_2legacy_8h.html#ac5899d1805c7fecd404dddcc7c1ae20a", null ],
    [ "MESSAGE_START_TESTNET", "_l_l_p_2packets_2legacy_8h.html#aab9223bd2842929e9f26c84b15c346a3", null ]
];