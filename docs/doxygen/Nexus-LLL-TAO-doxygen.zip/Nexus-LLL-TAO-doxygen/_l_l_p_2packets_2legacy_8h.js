var _l_l_p_2packets_2legacy_8h =
[
    [ "LegacyPacket", "class_l_l_p_1_1_legacy_packet.html", "class_l_l_p_1_1_legacy_packet" ],
    [ "NEXUS_LLP_PACKET_LEGACY_H", "_l_l_p_2packets_2legacy_8h.html#aaff1b1147d470b796b7dbb4a0db10006", null ],
    [ "MESSAGE_START_MAINNET", "_l_l_p_2packets_2legacy_8h.html#ac5899d1805c7fecd404dddcc7c1ae20a", null ],
    [ "MESSAGE_START_TESTNET", "_l_l_p_2packets_2legacy_8h.html#aab9223bd2842929e9f26c84b15c346a3", null ]
];