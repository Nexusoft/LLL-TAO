var class_legacy_1_1_key_pool =
[
    [ "KeyPool", "class_legacy_1_1_key_pool.html#aedf48796ac8228aac8cd0b0d4274cc30", null ],
    [ "AddKey", "class_legacy_1_1_key_pool.html#a2b74ace17b896f198c0e04786d6f45b7", null ],
    [ "ClearKeyPool", "class_legacy_1_1_key_pool.html#a109a0c424f7a51c3ab4f147311ec1575", null ],
    [ "GetKeyFromPool", "class_legacy_1_1_key_pool.html#a2a7d0cfb3271d437edc4989bd6815cc1", null ],
    [ "GetKeyPoolSize", "class_legacy_1_1_key_pool.html#a71323d883ec137dbac698b46dc425b55", null ],
    [ "GetOldestKeyPoolTime", "class_legacy_1_1_key_pool.html#a4a61dbc775aca4d89af4e295527b0349", null ],
    [ "KeepKey", "class_legacy_1_1_key_pool.html#a3d14c6a417cffaa88c9116f45f88af0b", null ],
    [ "NewKeyPool", "class_legacy_1_1_key_pool.html#a3b97b7444e2e1b1c110571e820046e1f", null ],
    [ "ReserveKeyFromPool", "class_legacy_1_1_key_pool.html#ac929423f443dee6beb6ab88c9cef08fe", null ],
    [ "ReturnKey", "class_legacy_1_1_key_pool.html#af14631f96e3cc3da1897782354cf4039", null ],
    [ "TopUpKeyPool", "class_legacy_1_1_key_pool.html#a98ac0d3b2c3be9ea4a18ba2ef41035c6", null ],
    [ "WalletDB", "class_legacy_1_1_key_pool.html#a5003a87231647e365602815a154a9980", null ]
];