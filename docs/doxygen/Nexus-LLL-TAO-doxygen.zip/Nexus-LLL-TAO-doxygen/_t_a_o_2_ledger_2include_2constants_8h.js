var _t_a_o_2_ledger_2include_2constants_8h =
[
    [ "hashGenesis", "_t_a_o_2_ledger_2include_2constants_8h.html#af2801b4f9119bb9422b185c7ee85ca5c", null ],
    [ "hashGenesisTestnet", "_t_a_o_2_ledger_2include_2constants_8h.html#a2246cd02a54585b54449b8c7454cf5fe", null ],
    [ "bnPrimeMinOrigins", "_t_a_o_2_ledger_2include_2constants_8h.html#acc6d5f05bcd82c79636c4dd760afef8a", null ],
    [ "bnProofOfWorkLimit", "_t_a_o_2_ledger_2include_2constants_8h.html#a57c6a26c432bfaa4db0d1cff3e337dfd", null ],
    [ "bnProofOfWorkStart", "_t_a_o_2_ledger_2include_2constants_8h.html#a6cc979cec7227dc315598a4dd6d7da30", null ],
    [ "MAINNET_MINIMUM_INTERVAL", "_t_a_o_2_ledger_2include_2constants_8h.html#a294036ac846c77bde9eca3bf7f783bbd", null ],
    [ "MAX_BLOCK_SIGOPS", "_t_a_o_2_ledger_2include_2constants_8h.html#ab5a1da24795c72c8ad1eebb43f53c238", null ],
    [ "MAX_BLOCK_SIZE", "_t_a_o_2_ledger_2include_2constants_8h.html#af4998a648e0d546a71f22dae79947d08", null ],
    [ "MAX_BLOCK_SIZE_GEN", "_t_a_o_2_ledger_2include_2constants_8h.html#a0de53f4024e70918c5cc3619fd7c6ded", null ],
    [ "MAX_STAKE_WEIGHT", "_t_a_o_2_ledger_2include_2constants_8h.html#afe1893f534f5d2b4ca7480cb550127cf", null ],
    [ "NEXUS_MATURITY_BLOCKS", "_t_a_o_2_ledger_2include_2constants_8h.html#ad1d506b71c465cfc8c8f95882230093a", null ],
    [ "TESTNET_MATURITY_BLOCKS", "_t_a_o_2_ledger_2include_2constants_8h.html#afa4411652a8ae6a917ea2718a297022d", null ],
    [ "TESTNET_MINIMUM_INTERVAL", "_t_a_o_2_ledger_2include_2constants_8h.html#a6209e18c58bb8f8e22cb94b11620b0c8", null ],
    [ "TRUST_KEY_EXPIRE", "_t_a_o_2_ledger_2include_2constants_8h.html#a214dc2c573f20b1d66a142085aade8c3", null ],
    [ "TRUST_KEY_TIMESPAN", "_t_a_o_2_ledger_2include_2constants_8h.html#ad72089756eef838ed6eca86b68660c31", null ],
    [ "TRUST_KEY_TIMESPAN_TESTNET", "_t_a_o_2_ledger_2include_2constants_8h.html#a872b61361897a0db525ada829bde8eef", null ]
];