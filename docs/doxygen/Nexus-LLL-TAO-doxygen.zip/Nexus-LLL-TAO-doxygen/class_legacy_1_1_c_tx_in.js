var class_legacy_1_1_c_tx_in =
[
    [ "CTxIn", "class_legacy_1_1_c_tx_in.html#a36642ea412c0d1bd590cb18d41d0d98d", null ],
    [ "CTxIn", "class_legacy_1_1_c_tx_in.html#a2f47e8c3844499e7750680795b294be4", null ],
    [ "IMPLEMENT_SERIALIZE", "class_legacy_1_1_c_tx_in.html#a0d4bbc21fc1212db12a7184f1577eac1", null ],
    [ "IsFinal", "class_legacy_1_1_c_tx_in.html#ac7696180fc7525c24adad2c698466339", null ],
    [ "IsStakeSig", "class_legacy_1_1_c_tx_in.html#a02bc53da568854cc58679724e04a48af", null ],
    [ "print", "class_legacy_1_1_c_tx_in.html#a601939cb53a772706e7ec1b6931f9fed", null ],
    [ "ToString", "class_legacy_1_1_c_tx_in.html#a7456007dfe0326209d73c1cf70659da5", null ],
    [ "ToStringShort", "class_legacy_1_1_c_tx_in.html#a5fcb7b4a3d18edd4497820050a7278b9", null ],
    [ "operator!=", "class_legacy_1_1_c_tx_in.html#a4188c5f0807185c03e80598a7a3ace72", null ],
    [ "operator==", "class_legacy_1_1_c_tx_in.html#a1bb37c4cd8573c3014a194e8ce4d8daa", null ],
    [ "nSequence", "class_legacy_1_1_c_tx_in.html#ada2cc823ae48531b04f5e3332049ecc9", null ],
    [ "prevout", "class_legacy_1_1_c_tx_in.html#aea3dc10c636352a6ecb1b1637dd08916", null ],
    [ "scriptSig", "class_legacy_1_1_c_tx_in.html#a246a406de18ec66a15a1a8c2a3b0d5b5", null ]
];