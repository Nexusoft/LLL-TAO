var _t_a_o_2_operation_2include_2enum_8h =
[
    [ "NEXUS_TAO_OPERATION_INCLUDE_ENUM_H", "_t_a_o_2_operation_2include_2enum_8h.html#aa0595ea893f5d04e3cf4c858068f5a56", null ],
    [ "VAL_TIMESTAMP", "_t_a_o_2_operation_2include_2enum_8h.html#a637a7a07a0f1199840c8d92a4ba8f23fa40b014a50778b75cbf66d4af6fcc8a2b", null ],
    [ "OP", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226", [
      [ "WRITE", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a8b3b7980a842fe50201feada76efb2f4", null ],
      [ "REGISTER", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a5743a99ba57085395457c1b409d34e94", null ],
      [ "AUTHORIZE", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a7c4cd9ec76de55103bb426d5b9920c09", null ],
      [ "TRANSFER", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226ab351193ef9df69805ef82d0d9bc4fc8d", null ],
      [ "REQUIRE", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226af6991c6568de5a474694b85d2d2c3da9", null ],
      [ "APPEND", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a45a1a18c4e7d318b4c8a36d860e85d49", null ],
      [ "DEBIT", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226ac3e16da5b6977b57f6c86e46e42f8cc9", null ],
      [ "CREDIT", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226ac6cca87312229db9c0dac6d0840904c2", null ],
      [ "COINBASE", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a77ce50fe6d5a82ac19144b5d8cce8031", null ],
      [ "TRUST", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a7e61fd500ec4f51a6e63d01d58b29426", null ],
      [ "AMBASSADOR", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a14cd9f2f4de9a8f9af78562a76175c1c", null ],
      [ "DEVELOPER", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226aa7350e18a03bf06e1b00a4b7958cad84", null ],
      [ "SIGNATURE", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226aeaa8b4ae7563dace5563953a2d1b6abd", null ],
      [ "VOTE", "_t_a_o_2_operation_2include_2enum_8h.html#a2909821a23cbefc93937b0e3694f5226a95d27eb24363aec63e6affbd5df0381c", null ]
    ] ],
    [ "VALIDATE", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9", [
      [ "IF", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9ab3618ca41212735cb2907318b2396f58", null ],
      [ "ELSE", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a3dc2b9245a13ee9751e3bff797e9ae19", null ],
      [ "ENDIF", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a17487161a0fe82e59da1fae40e43a065", null ],
      [ "AND", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9af023358c8c8c307df202a44f0384979e", null ],
      [ "OR", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9aa73c4abb188c45789cb04adb51a107a9", null ],
      [ "EQUALS", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a03d2c9dd7f44dde73db0b9a353047283", null ],
      [ "NOT", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a55941b10631b629105ad7ad367cabc13", null ],
      [ "LESSTHAN", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a0b9bb01f4b7ed41cfc6bf6b709fd510e", null ],
      [ "GREATTHAN", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a0d89dd67271ef6c0e1787c728633c086", null ],
      [ "RETURN", "_t_a_o_2_operation_2include_2enum_8h.html#acf35cbd00c9f54e5423261fb668f8eb9a48bbcb6de757aa0db78445fca91a0b66", null ]
    ] ]
];