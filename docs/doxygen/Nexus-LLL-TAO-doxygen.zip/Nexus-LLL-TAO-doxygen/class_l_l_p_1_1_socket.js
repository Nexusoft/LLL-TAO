var class_l_l_p_1_1_socket =
[
    [ "Socket", "class_l_l_p_1_1_socket.html#a3e4ab953c2b130999d8f8e89d73f98e5", null ],
    [ "Socket", "class_l_l_p_1_1_socket.html#a293d5145e6f64673fbf5165a2486b65e", null ],
    [ "Socket", "class_l_l_p_1_1_socket.html#aec7dad23572fd5a324191f2ac2c98d24", null ],
    [ "Attempt", "class_l_l_p_1_1_socket.html#ad792c3582e40504526ddd3c6e2049c37", null ],
    [ "Available", "class_l_l_p_1_1_socket.html#a3c166d5544034dd0c09a90a02719fb71", null ],
    [ "Close", "class_l_l_p_1_1_socket.html#accfb3c200c49b3201638a831e9d6e601", null ],
    [ "ErrorCode", "class_l_l_p_1_1_socket.html#a4d7acfc521f58485a3eb398015be8e4c", null ],
    [ "Flush", "class_l_l_p_1_1_socket.html#a99598102db00df4c09208f3a1cb838c5", null ],
    [ "Read", "class_l_l_p_1_1_socket.html#a3d20e998d205c2ab3df8f50209b8b973", null ],
    [ "Read", "class_l_l_p_1_1_socket.html#a0272fec1299d0dac95c83294a843bf38", null ],
    [ "Write", "class_l_l_p_1_1_socket.html#a609f8b13f614a53037e75140b77c5a27", null ],
    [ "addr", "class_l_l_p_1_1_socket.html#aa0804b8f4c7686f794b550bb5bd49ee7", null ],
    [ "nError", "class_l_l_p_1_1_socket.html#a934e819d6cfbd8a632fcf9f81062412f", null ],
    [ "nLastRecv", "class_l_l_p_1_1_socket.html#a59fe35834c3ea4ddd9aeeecd985c46c9", null ],
    [ "nLastSend", "class_l_l_p_1_1_socket.html#ae5174427a0bd03a626318a8775d683ab", null ],
    [ "vBuffer", "class_l_l_p_1_1_socket.html#a4a5a2233da0d2ac7eb0102144cc15631", null ]
];